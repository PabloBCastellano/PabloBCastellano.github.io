from PyQt5.QtWidgets import QApplication, QFileDialog, QLabel, QWidget, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon
from PyQt5 import uic
import sys
import smtplib
from email.mime.text import MIMEText


class EnviarCorreo(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        uic.loadUi("Compartir_aplicacion.ui", self)
        self.setWindowTitle("Recomendar Aplicacion")
        self.Email_Text.setText("Comparteme ")
    def Enviar_Recomendacion(self):
        self.Correo_Usuario = self.UserMail.text()
        self.Clave_Usuario = self.UserPassword.text()
        self.Correo_Destinatario = self.User_Final.text()
        # self.Cuerpo_Mensaje = self.Email_Text.toPlainText()
        # self.Cuerpo_Mensaje.setText("Comparteme")
        emisor = "pablo.branuelas@campusfp.es"
        receptor = "pablobranuelascastellano@hotmail.com"
        mensaje = MIMEText("Este correo ha sido enviado desde Python")
        mensaje['From'] = emisor
        mensaje['To'] = receptor
        mensaje['Subject'] = "Mi primer correo desde Python"
        # Nos conectamos al servidor SMTP de Gmail
        try:
            serverSMTP = smtplib.SMTP('smtp.gmail.com', 587)
        except Exception as Error:
            print(str(Error))
        serverSMTP.ehlo()
        serverSMTP.starttls()
        serverSMTP.ehlo()
        serverSMTP.login(emisor, "Pablo2508/95")
        # Enviamos el mensaje
        try:
            serverSMTP.sendmail(emisor, receptor, mensaje.as_string())
            print("Correo enviado correctamente")
        except Exception as Error:
            print(str(Error))
        # Cerramos la conexion
        serverSMTP.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    Enviar = EnviarCorreo()
    Enviar.show()
    app.exec_()

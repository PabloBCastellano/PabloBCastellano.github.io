# -*- coding: utf-8 -*-
import sys
import re
import os

import time
from PyQt5.QtWidgets import QApplication, QLabel, QWidget, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon
from PyQt5 import uic


class Conexion_Maridb(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        QLabel.__init__(self)
        uic.loadUi("Acceso_Usuario.ui", self)
        self.setWindowTitle("Inicio de Sesión MariaDB")
        self.Iniciar_Sesion.clicked.connect(self.Establecer_Conexion)

    def Establecer_Conexion(self):
        self.username = self.Name_User.text()
        self.password = self.Pass_User.text()
        self.close()

    def Salir_Cuadro(self):

        self.close()


if __name__ == '__main__':
    Almacenar = QApplication(sys.argv)
    Iniciar = Ventana_Conexion()
    Iniciar.show()
    Almacenar.exec_()

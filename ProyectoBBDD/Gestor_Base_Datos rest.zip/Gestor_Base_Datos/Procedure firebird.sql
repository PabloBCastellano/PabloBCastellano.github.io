CREATE OR ALTER PROCEDURE PABLO(param_entrada  integer) returns( identificador int  ,Nombre varchar(50),salida varchar(50) ,res int ) 
AS
DECLARE VARIABLE cantidad int;
DECLARE VARIABLE resultado int;

	BEGIN
		
		res=:param_entrada;
		/*cantidad=(SELECT COUNT(*) FROM COLORES);
		IF (cantidad>10)THEN
		
			salida='No hay mas de 3 datos';
			
		ELSE
			salida='Hay mas de 3 valores';
		suspend;
		*/
		FOR SELECT * FROM Colores  WHERE Id=:param_entrada into :identificador,:Nombre
			do 
			BEGIN
				/*Nombre=Nombre;
				res=identificador;
				
				*/
				
				suspend;
			END
			
END


/*EXECUTE PROCEDURE Pablo;*/
SELECT * FROM Pablo(1);

/*DROP PROCEDURE Pablo;*/

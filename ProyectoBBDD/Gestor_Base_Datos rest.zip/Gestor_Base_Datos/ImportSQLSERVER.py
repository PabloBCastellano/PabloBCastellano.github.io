import os
usuario = 'sa'
clave = 'rootroot'
salida = []
dir_actual = (os.getcwd()+(str(os.path.sep)))
print(dir_actual)
Carpeta_Seguridad = "Bases_Datos_SQLSERVER"
Encontrar = 0


def Restaurar_Bases(*args):
    os.chdir(dir_actual+str(Carpeta_Seguridad))
    Nuevo_Directorio = (os.getcwd()+str(os.path.sep))
    print(Nuevo_Directorio)
    for each in os.listdir(Nuevo_Directorio):
        salida.append(each)

    for x in range(len(salida)):
        importar = salida[x]
        print(importar)
        os.system("sqlcmd -S localhost -U "+str(usuario)+" -P "+str(clave)+" -Q \"RESTORE DATABASE ["+str(importar).replace(".bak","")+"] FROM DISK = N'"+str(
        Nuevo_Directorio)+str(importar)+"' WITH FILE = 1, NOUNLOAD, REPLACE, NORECOVERY, STATS = 5\"")
        os.system("sqlcmd -S localhost -U "+str(usuario)+" -P "+str(clave)+" -Q \"RESTORE LOG " +
                  str(importar).replace(".bak","")+" FROM DISK = N'"+str(Nuevo_Directorio)+str(importar)+"'\"")


for each in(os.listdir()):

    if(each == Carpeta_Seguridad):
        Encontrar = 1
        break
    else:
        Encontrar = 0

if(Encontrar == 0):
    print("La carpeta no Existe")

else:
    Restaurar_Bases()

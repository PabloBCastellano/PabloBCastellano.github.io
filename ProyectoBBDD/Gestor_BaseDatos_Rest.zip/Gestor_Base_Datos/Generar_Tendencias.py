import sys
import os
import pandas as pd
from pytrends.request import TrendReq
from PyQt5.QtGui import QFont
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
import time
import datetime
from pandas import DataFrame


class Tendencia_Global(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        QLabel.__init__(self)

        uic.loadUi("Tendencias.ui", self)

    def Rellenar_Tabla(self):
        
        self.Fecha_actual = datetime.datetime.now()
        
        
        self.pytrend = TrendReq()
        try:
            self.Estadisticas.clear()
            
            self.Texto_Buscar = self.Dato_Entrada.value()
            self.df = self.pytrend.top_charts(
                int(self.Texto_Buscar), hl='en-UK', tz=300, geo='GLOBAL')
            # print(type(self.df))
            self.records = self.df.to_records(index=True)
            print(self.records)
            print(type(self.records))
            self.Encabezado = list(pd.DataFrame(self.records))
            

            self.Estadisticas.setRowCount(len(self.records))
            self.Estadisticas.setColumnCount(len(self.records[0])-1)
            row = 0

            for each in self.records:

                for val in range(len(each)):
                    self.Estadisticas.setItem(
                        row, val, QTableWidgetItem(str(each[val])))

                row += 1
                self.Estadisticas.setHorizontalHeaderLabels(self.Encabezado)
        except IndexError:
            self.Estadisticas.setHorizontalHeaderLabels(["",""])
            QMessageBox.warning(self, "ERROR", "Google solo dispone de datos a partir del 2001 hasta el " +
                                str(int(self.Fecha_actual.year - 1)), QMessageBox.Discard)


if __name__ == '__main__':
    programa = QApplication(sys.argv)
    Generar_Informacion = Tendencia_Global()
    Generar_Informacion.show()
    programa.exec_()

from PyQt5.QtWidgets import QApplication, QFileDialog, QLabel, QWidget, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon
from PyQt5 import uic
import sys
import smtplib
from email.mime.text import MIMEText


class EnviarCorreo(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        uic.loadUi("Compartir_aplicacion.ui", self)
        self.setWindowTitle("Recomendar Aplicacion")
        self.Email_Text.setText("""Desactiva el acceso de aplicaciones poco seguras desde\nhttps://myaccount.google.com/u/0/lesssecureapps?pageId=none y Comparteme, me puedes descargar en este enlace:\n\n https://github.com/PabloBCastellano/PabloBCastellano.github.io/blob/master/ProyectoBBDD/Gestor_Base_Datos%20rest.zip .\n\nAdemas de algun tipo de base de datos como Mysql,Sqlite,SQL SERVER ,Firebird o Postgresql.\nNecesitas tener instaladas las librerias:
        1)PyQt5.
        2)fpdf.
        3)xlrd.
        4)urllib.
        5)pyodbc.
        6)pandas.
        7)pillow.
        8)fdb.
        9)numpy.
        10)matplotlib.
        11)psycopg2.
        12)seaborn.
        13)json.\n
        """)

    def Enviar_Recomendacion(self):
        self.Correo_Usuario = self.UserMail.text()
        self.Clave_Usuario = self.UserPassword.text()
        self.Correo_Destinatario = self.User_Final.text()
        self.Cuerpo_Mensaje = self.Email_Text.toPlainText()
        # self.Cuerpo_Mensaje.setText("Comparteme")
        emisor = self.Correo_Usuario
        receptor = self.Correo_Destinatario
        mensaje = MIMEText(self.Cuerpo_Mensaje)
        mensaje['From'] = emisor
        mensaje['To'] = receptor
        mensaje['Subject'] = "Compartir Aplicacion base de datos"
        # Nos conectamos al servidor SMTP de Gmail
        serverSMTP = smtplib.SMTP('smtp.gmail.com', 587)
        serverSMTP.ehlo()
        serverSMTP.starttls()
        serverSMTP.ehlo()
        try:
            serverSMTP.login(emisor, self.Clave_Usuario)
        except Exception as Error:
            QMessageBox.warning(
                self, "ERROR", "Clave,correo del usuario incorrecto o el destino no permite el acceso", QMessageBox.Discard)

        # Enviamos el mensaje
        try:
            serverSMTP.sendmail(emisor, receptor, mensaje.as_string())
            QMessageBox.information(
                self, "Envio Realizado", "El correo se ha enviado correctamente", QMessageBox.Ok)
            self.close()
        except Exception as Error:
            QMessageBox.warning(
                self, "ERROR", "NO se ha podido enviar el correo.Compruebe los datos introducidos", QMessageBox.Discard)
        # Cerramos la conexion
        serverSMTP.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    Enviar = EnviarCorreo()
    Enviar.show()
    app.exec_()

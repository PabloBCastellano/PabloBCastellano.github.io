-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: aula_virtual
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `aula_virtual`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `aula_virtual` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `aula_virtual`;

--
-- Table structure for table `alumnos`
--

DROP TABLE IF EXISTS `alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumnos` (
  `AlumnoId` int NOT NULL AUTO_INCREMENT,
  `CentroEducativoId` int NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `PrimerApellido` varchar(100) NOT NULL,
  `SegundoApellido` varchar(100) NOT NULL,
  `NIF_NIE` varchar(10) NOT NULL,
  `FechaAlta` date NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Usuario` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `EsActivo` tinyint(1) NOT NULL,
  PRIMARY KEY (`AlumnoId`),
  KEY `CentroEducativoId` (`CentroEducativoId`),
  CONSTRAINT `alumnos_ibfk_1` FOREIGN KEY (`CentroEducativoId`) REFERENCES `centroseducativos` (`CentroEducativoId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='En esta tabla se registran los datos de los alumnos y\r\n	 al centro educativo que pertenecen';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumnos`
--

LOCK TABLES `alumnos` WRITE;
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` VALUES (1,1,'Paco','Peluca','Peluca','135664W','1940-12-20','Paco.Peluca@gamil.com','Paco Peluca Peluca','6d30a43d109544eaec2283e4d5aedf44',1);
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `centroseducativos`
--

DROP TABLE IF EXISTS `centroseducativos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `centroseducativos` (
  `CentroEducativoId` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) NOT NULL,
  `Administrador` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  PRIMARY KEY (`CentroEducativoId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='En esta tabla de indican los centros Educativos,el Id del centro,\r\n	 el nombre del Administrador y la clave de acceso';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `centroseducativos`
--

LOCK TABLES `centroseducativos` WRITE;
/*!40000 ALTER TABLE `centroseducativos` DISABLE KEYS */;
INSERT INTO `centroseducativos` VALUES (1,'IES GRAN CAPITAN','Pepe','12585');
/*!40000 ALTER TABLE `centroseducativos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuestionarios`
--

DROP TABLE IF EXISTS `cuestionarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cuestionarios` (
  `CuestionarioId` int NOT NULL AUTO_INCREMENT,
  `ProfesorId` int NOT NULL,
  `Titulo` varchar(100) NOT NULL,
  `Instrucciones` text NOT NULL,
  `Resumen` text NOT NULL,
  `NumeroPreguntasPorTest` int NOT NULL,
  `PuntosAcierto` float NOT NULL,
  `PuntosError` float NOT NULL,
  `FechaCreacion` date NOT NULL,
  `EsActivo` tinyint(1) NOT NULL,
  PRIMARY KEY (`CuestionarioId`),
  KEY `ProfesorId` (`ProfesorId`),
  CONSTRAINT `cuestionarios_ibfk_1` FOREIGN KEY (`ProfesorId`) REFERENCES `profesores` (`ProfesorId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Esta tabla contiene las intrucciones ,el numero de preguntas,\r\n	el numero de aciertos y fallos y cuando se creo';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuestionarios`
--

LOCK TABLES `cuestionarios` WRITE;
/*!40000 ALTER TABLE `cuestionarios` DISABLE KEYS */;
INSERT INTO `cuestionarios` VALUES (1,1,'Examen tema 1','Completar las cuestiones siguientes','Prueba',10,1,0.25,'2020-06-08',1),(2,1,'La Primera Guerra Mundial','1º Examen 2º  Evaluación Periodo 1º Mitad del Siglo XX','Este examen abarca desde el Imperialismo hasta la formación de la Sociedad De Naciones(SDN)',5,1,-0.5,'2020-06-10',1),(3,1,'La Guerra Fría','Este examen es el ultimo de la 3ª evaluacion','Guerra Fría desde 1946',20,1,-0.5,'2020-06-12',1);
/*!40000 ALTER TABLE `cuestionarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuestionariosgrupos`
--

DROP TABLE IF EXISTS `cuestionariosgrupos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cuestionariosgrupos` (
  `CuestionarioGrupoId` int NOT NULL AUTO_INCREMENT,
  `CuestionarioId` int NOT NULL,
  `GrupoId` int NOT NULL,
  `FechaInicio` date NOT NULL,
  `FechaFin` date NOT NULL,
  PRIMARY KEY (`CuestionarioGrupoId`),
  KEY `CuestionarioId` (`CuestionarioId`),
  KEY `GrupoId` (`GrupoId`),
  CONSTRAINT `cuestionariosgrupos_ibfk_1` FOREIGN KEY (`CuestionarioId`) REFERENCES `cuestionarios` (`CuestionarioId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cuestionariosgrupos_ibfk_2` FOREIGN KEY (`GrupoId`) REFERENCES `grupos` (`GrupoId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Esta tabla contiene el identificador del cuestioanario,\r\n	que grupo lo ha realizado ,cuando se inició y cuando se termino';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuestionariosgrupos`
--

LOCK TABLES `cuestionariosgrupos` WRITE;
/*!40000 ALTER TABLE `cuestionariosgrupos` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuestionariosgrupos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cursosacademicos`
--

DROP TABLE IF EXISTS `cursosacademicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cursosacademicos` (
  `CursoAcademicoId` int NOT NULL AUTO_INCREMENT,
  `CentroEducativoId` int NOT NULL,
  `Denominacion` varchar(100) NOT NULL,
  `EsActivo` tinyint(1) NOT NULL,
  `FechaInicio` date NOT NULL,
  `FechaFin` date NOT NULL,
  PRIMARY KEY (`CursoAcademicoId`),
  KEY `CentroEducativoId` (`CentroEducativoId`),
  CONSTRAINT `cursosacademicos_ibfk_1` FOREIGN KEY (`CentroEducativoId`) REFERENCES `centroseducativos` (`CentroEducativoId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='En esta tabla se registran los distintos cursos academicos\r\n	 que tiene cada centro con fecha de inicio y fecha de fin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cursosacademicos`
--

LOCK TABLES `cursosacademicos` WRITE;
/*!40000 ALTER TABLE `cursosacademicos` DISABLE KEYS */;
INSERT INTO `cursosacademicos` VALUES (1,1,'2019/2020',1,'2019-09-15','2020-06-25'),(2,1,'2015/2016',0,'2015-09-15','2016-06-15');
/*!40000 ALTER TABLE `cursosacademicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grupos`
--

DROP TABLE IF EXISTS `grupos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grupos` (
  `GrupoId` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) NOT NULL,
  `CursoAcademicoId` int NOT NULL,
  `MateriaId` int NOT NULL,
  `NivelId` int NOT NULL,
  `ProfesorId` int NOT NULL,
  PRIMARY KEY (`GrupoId`),
  KEY `CursoAcademicoId` (`CursoAcademicoId`),
  KEY `MateriaId` (`MateriaId`),
  KEY `NivelId` (`NivelId`),
  KEY `ProfesorId` (`ProfesorId`),
  CONSTRAINT `grupos_ibfk_1` FOREIGN KEY (`CursoAcademicoId`) REFERENCES `cursosacademicos` (`CursoAcademicoId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `grupos_ibfk_2` FOREIGN KEY (`MateriaId`) REFERENCES `materias` (`MateriaId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `grupos_ibfk_3` FOREIGN KEY (`NivelId`) REFERENCES `niveles` (`NivelId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `grupos_ibfk_4` FOREIGN KEY (`ProfesorId`) REFERENCES `profesores` (`ProfesorId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Esta tabla contiene el nombre del grupo ,el curso academico,\r\n	la materia,el nivel y el profesor que la imparte';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grupos`
--

LOCK TABLES `grupos` WRITE;
/*!40000 ALTER TABLE `grupos` DISABLE KEYS */;
INSERT INTO `grupos` VALUES (1,'1ºH',1,1,1,1),(2,'1ºA',2,3,1,1),(3,'1ºC',1,2,1,1);
/*!40000 ALTER TABLE `grupos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gruposalumnos`
--

DROP TABLE IF EXISTS `gruposalumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gruposalumnos` (
  `GrupoAlumnoId` int NOT NULL AUTO_INCREMENT,
  `GrupoId` int NOT NULL,
  `AlumnoId` int NOT NULL,
  PRIMARY KEY (`GrupoAlumnoId`),
  KEY `GrupoId` (`GrupoId`),
  KEY `AlumnoId` (`AlumnoId`),
  CONSTRAINT `gruposalumnos_ibfk_1` FOREIGN KEY (`GrupoId`) REFERENCES `grupos` (`GrupoId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gruposalumnos_ibfk_2` FOREIGN KEY (`AlumnoId`) REFERENCES `alumnos` (`AlumnoId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Esta tabla contiene los codigos de los alumnos y del grupo';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gruposalumnos`
--

LOCK TABLES `gruposalumnos` WRITE;
/*!40000 ALTER TABLE `gruposalumnos` DISABLE KEYS */;
INSERT INTO `gruposalumnos` VALUES (1,1,1),(2,3,1),(3,2,1);
/*!40000 ALTER TABLE `gruposalumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `intentos`
--

DROP TABLE IF EXISTS `intentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `intentos` (
  `IntentoId` int NOT NULL AUTO_INCREMENT,
  `AlumnoId` int NOT NULL,
  `CuestionarioId` int NOT NULL,
  `FechaComienzo` date NOT NULL,
  `FechaFin` date NOT NULL,
  `TiempoTotal` int NOT NULL,
  `Puntuacion` int NOT NULL,
  `Finalizado` tinyint(1) NOT NULL,
  PRIMARY KEY (`IntentoId`),
  KEY `AlumnoId` (`AlumnoId`),
  KEY `CuestionarioId` (`CuestionarioId`),
  CONSTRAINT `intentos_ibfk_1` FOREIGN KEY (`AlumnoId`) REFERENCES `alumnos` (`AlumnoId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `intentos_ibfk_2` FOREIGN KEY (`CuestionarioId`) REFERENCES `cuestionarios` (`CuestionarioId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Esta tabla contiene el numero de veces que los alumnos han intentado los \r\n	cuestionarios,cuando han empezado ,cuando lo han terminado ,los puntos obtenidos \r\n	y el tiempo que han tardado';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `intentos`
--

LOCK TABLES `intentos` WRITE;
/*!40000 ALTER TABLE `intentos` DISABLE KEYS */;
/*!40000 ALTER TABLE `intentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materias`
--

DROP TABLE IF EXISTS `materias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `materias` (
  `MateriaId` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) NOT NULL,
  `CentroEducativoId` int NOT NULL,
  `EsActiva` tinyint(1) NOT NULL,
  PRIMARY KEY (`MateriaId`),
  KEY `CentroEducativoId` (`CentroEducativoId`),
  CONSTRAINT `materias_ibfk_1` FOREIGN KEY (`CentroEducativoId`) REFERENCES `centroseducativos` (`CentroEducativoId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Esta tabla contendrá las materias que impartirá cada centro';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materias`
--

LOCK TABLES `materias` WRITE;
/*!40000 ALTER TABLE `materias` DISABLE KEYS */;
INSERT INTO `materias` VALUES (1,'Historia del Mundo Contemporaneo',1,1),(2,'Historia del Arte',1,1),(3,'Economia de la Empresa',1,1);
/*!40000 ALTER TABLE `materias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `niveles`
--

DROP TABLE IF EXISTS `niveles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `niveles` (
  `NivelId` int NOT NULL AUTO_INCREMENT,
  `CentroEducativoId` int NOT NULL,
  `Denominacion` varchar(100) NOT NULL,
  `EsActivo` tinyint(1) NOT NULL,
  PRIMARY KEY (`NivelId`),
  KEY `CentroEducativoId` (`CentroEducativoId`),
  CONSTRAINT `niveles_ibfk_1` FOREIGN KEY (`CentroEducativoId`) REFERENCES `centroseducativos` (`CentroEducativoId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Esta tabla contiene los diferentes niveles de estudios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `niveles`
--

LOCK TABLES `niveles` WRITE;
/*!40000 ALTER TABLE `niveles` DISABLE KEYS */;
INSERT INTO `niveles` VALUES (1,1,'1ºESO',1),(2,1,'4ºESO',1);
/*!40000 ALTER TABLE `niveles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opciones`
--

DROP TABLE IF EXISTS `opciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opciones` (
  `OpcionId` int NOT NULL AUTO_INCREMENT,
  `PreguntaId` int NOT NULL,
  `Texto` text NOT NULL,
  `EsCorrecta` tinyint(1) NOT NULL,
  `FechaCreacion` date NOT NULL,
  `Orden` int NOT NULL,
  `EsActivo` tinyint(1) NOT NULL,
  PRIMARY KEY (`OpcionId`),
  KEY `PreguntaId` (`PreguntaId`),
  CONSTRAINT `opciones_ibfk_1` FOREIGN KEY (`PreguntaId`) REFERENCES `preguntas` (`PreguntaId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='Esta tabla contiene las opciones de las distintas preguntas ,\r\n	cuando se crearon ,en que orden se muestran y\r\n	si es correcta o no';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opciones`
--

LOCK TABLES `opciones` WRITE;
/*!40000 ALTER TABLE `opciones` DISABLE KEYS */;
INSERT INTO `opciones` VALUES (1,1,'1859',0,'2020-06-08',1,1),(2,1,'1763',1,'2020-06-08',2,1),(3,1,'1868',0,'2020-06-08',3,1),(4,2,'1)Lanzadera Volante,Barco de Vapor,Maquina de Vapor',1,'2020-06-08',1,1),(5,2,'Alumbrado electrico,Altos Hornos,Lanzadera Volante',1,'2020-06-08',2,1),(6,2,'Produccion en Serie,Nuevos Transportes,Alumbrado Publico',0,'2020-06-08',3,1),(7,3,'Nueva forma de fabricar metales',1,'2020-06-08',1,1),(8,3,'Nuevas Aleaciones',1,'2020-06-08',2,1),(9,3,'Primeros altos Hornos',0,'2020-06-08',3,1);
/*!40000 ALTER TABLE `opciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opcionespuntos`
--

DROP TABLE IF EXISTS `opcionespuntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opcionespuntos` (
  `OpcionPuntoId` int NOT NULL AUTO_INCREMENT,
  `OpcionId` int NOT NULL,
  `PuntoId` int NOT NULL,
  PRIMARY KEY (`OpcionPuntoId`),
  KEY `OpcionId` (`OpcionId`),
  KEY `PuntoId` (`PuntoId`),
  CONSTRAINT `opcionespuntos_ibfk_1` FOREIGN KEY (`OpcionId`) REFERENCES `opciones` (`OpcionId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `opcionespuntos_ibfk_2` FOREIGN KEY (`PuntoId`) REFERENCES `puntos` (`PuntoId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='Esta tabla guarda la respuesta elegida\r\n	 y a que punto corresponde';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opcionespuntos`
--

LOCK TABLES `opcionespuntos` WRITE;
/*!40000 ALTER TABLE `opcionespuntos` DISABLE KEYS */;
INSERT INTO `opcionespuntos` VALUES (1,1,3),(2,2,3),(3,3,3),(4,4,4),(5,5,4),(6,6,4),(7,7,4),(8,8,4),(9,9,4);
/*!40000 ALTER TABLE `opcionespuntos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preguntas`
--

DROP TABLE IF EXISTS `preguntas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preguntas` (
  `PreguntaId` int NOT NULL AUTO_INCREMENT,
  `CuestionarioId` int NOT NULL,
  `Texto` text NOT NULL,
  `FechaCreacion` date NOT NULL,
  `Orden` int NOT NULL,
  `EsActivo` tinyint(1) NOT NULL,
  PRIMARY KEY (`PreguntaId`),
  KEY `CuestionarioId` (`CuestionarioId`),
  CONSTRAINT `preguntas_ibfk_1` FOREIGN KEY (`CuestionarioId`) REFERENCES `cuestionarios` (`CuestionarioId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='Esta tabla contiene las preguntas,a  que formulario pertenecen,\r\n	el orden en que se muestran y cuando se crearon';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preguntas`
--

LOCK TABLES `preguntas` WRITE;
/*!40000 ALTER TABLE `preguntas` DISABLE KEYS */;
INSERT INTO `preguntas` VALUES (1,1,'En que año creo James Watt la maquina de vapor','2020-06-08',5,1),(2,1,'Principales inventos de la revolución Industrial','2020-06-08',1,1),(3,1,'Como afectó la industrialización a la metalurgia','2020-06-08',10,1),(4,2,'Causas de la Primera Guerra Mundial','2020-06-13',1,1),(5,2,'Etapas de la Guerra','2020-06-13',2,1),(6,2,'Bandos que se formaron INICIALMENTE','2020-06-13',3,1),(7,2,'Tratados de Paz que hubo tras finalizar la Guerra','2020-06-13',4,1),(8,2,'Que es la Sociedad De Naciones','2020-06-13',5,1);
/*!40000 ALTER TABLE `preguntas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profesores`
--

DROP TABLE IF EXISTS `profesores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profesores` (
  `ProfesorId` int NOT NULL AUTO_INCREMENT,
  `CentroEducativoId` int NOT NULL,
  `Nombre` varchar(100) NOT NULL,
  `PrimerApellido` varchar(100) NOT NULL,
  `SegundoApellido` varchar(100) NOT NULL,
  `NIF_NIE` varchar(10) NOT NULL,
  `FechaAlta` date NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Usuario` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `EsActivo` tinyint(1) NOT NULL,
  PRIMARY KEY (`ProfesorId`),
  KEY `CentroEducativoId` (`CentroEducativoId`),
  CONSTRAINT `profesores_ibfk_1` FOREIGN KEY (`CentroEducativoId`) REFERENCES `centroseducativos` (`CentroEducativoId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='En esta tabla se registran los datos de los profesores y\r\n	 a que centro pertenecen';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profesores`
--

LOCK TABLES `profesores` WRITE;
/*!40000 ALTER TABLE `profesores` DISABLE KEYS */;
INSERT INTO `profesores` VALUES (1,1,'Miguel','Herguedas','Heredias','15428562S','1960-02-15','MiguelHistoria@gmail.com','Miguel Herguedas Heredias','fe2c270b68bc91b8c6d4abd5cb3c0755',1),(2,1,'Javier','Ortega ','Cano','453531Q','2008-03-30','JavierOrtega@gmail.com','Javier Ortega Cano','1c8d5439478c6d9124f0516c4c9c5c29',1);
/*!40000 ALTER TABLE `profesores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `puntos`
--

DROP TABLE IF EXISTS `puntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `puntos` (
  `PuntoId` int NOT NULL AUTO_INCREMENT,
  `TemaId` int NOT NULL,
  `Titulo` varchar(100) NOT NULL,
  `Resumen` text NOT NULL,
  `Texto` text NOT NULL,
  `Orden` int NOT NULL,
  `Numero` int NOT NULL,
  `EsActivo` tinyint(1) NOT NULL,
  PRIMARY KEY (`PuntoId`),
  KEY `TemaId` (`TemaId`),
  CONSTRAINT `puntos_ibfk_1` FOREIGN KEY (`TemaId`) REFERENCES `temas` (`TemaId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='Esta tabla contiene los apartados que tiene cada tema ,\r\n	numero y orden en que se va a presentar';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `puntos`
--

LOCK TABLES `puntos` WRITE;
/*!40000 ALTER TABLE `puntos` DISABLE KEYS */;
INSERT INTO `puntos` VALUES (1,2,'Causas de la Revolución Francesa','Principales Causas que provocaron la caida del Antiguo Régimen y del fin del Absolutismo.','Las principales causas de la Revolución francesa fueron las siguientes:\r\n\r\n1)Las arbitrariedades de un absolutismo monárquico que oprimía a la mayoría de sus súbditos.\r\n\r\n2)Una gran desigualdad social debido a las fuertes cargas (impuestos, tributos y diezmo) que recaían sobre los campesinos franceses, quienes con su trabajo debían mantenerse a sí mismos y a los grupos privilegiados: la nobleza y el clero.\r\n\r\n3)El descontento de sectores intelectuales por la falta de derechos y libertades. Estos intelectuales estaban muy influidos por las ideas de la Ilustración.\r\n\r\n4)La crisis económica y financiera en la que se encontraba Francia. Los excesos de gastos de la Corona y los gastos provenientes de la participación en la guerra por la Independencia de Estados Unidos habían provocado un déficit presupuestario.\r\n\r\n5)Una serie de malas cosechas que provocaron aumentos desmedidos del precio del pan, que era el principal alimento de los sectores populares.\r\n\r\n6)Las aspiraciones de una burguesía en ascenso que deseaba que su posición económica se correspondiera con su situación social y sus derechos políticos.',1,1,1),(2,2,'Consecuencias de la Revolución Francesa','La Revolución Francesa tras pasar por distintas etapas,finalmente fracaso.','Las principales consecuencias de la Revolución francesa fueron las siguientes:\r\n\r\n1)Fin del sistema feudal: la Revolución francesa suprimió todas las expresiones del feudalismo, entre ellas la servidumbre, el pago de tributos, los privilegios del clero y la nobleza.\r\n\r\n2)Declaración de nuevos derechos individuales: libertad, igualdad ante la ley, abolición de la esclavitud, entre otros. Estas ideas se expandieron por toda Europa e influyeron sobre los líderes de las revoluciones de independencia en América.\r\n\r\n3)Supresión de la monarquía absoluta y establecimiento de un sistema republicano con división de poderes, elección de los funcionarios por parte del pueblo y duración limitada en los cargos públicos.\r\n\r\n4)Ascenso de la burguesía, que paulatinamente se transformó en el grupo social predominante en Francia.\r\n\r\n5)Extensión de la guerra en Europa, debido al intento de las monarquías del continente de unirse para restaurar el Antiguo Régimen.\r\n\r\n6)Ascenso al poder de Napoleón Bonaparte, como consecuencia de las victorias militares contra las potencias extranjeras. El resultado fue paradójico: Napoleón salvó a la Revolución francesa de sus enemigos exteriores para luego terminar con ella y reemplazarla por un sistema monárquico imperial. Tras su derrota se restauró la monarquía absoluta y Luis XVIII fue coronado como rey de Francia.',3,3,1),(3,1,'¿Qué es la Revolución Industrial?','Definicion de lo que fue la Revolución Indutrial en Inglaterra.','La Revolución Industrial es un período histórico de transformaciones económicas y sociales, entre 1760 y 1840, que desencadenó cambios sin precedentes para las sociedades de todo el mundo.\r\n\r\nSe caracterizó por el uso de nuevas tecnologías aplicadas a la producción en masa (también denominada, producción en serie). La primera invención que permitió esta nueva forma de producción fue la máquina de vapor, cuyo combustible era el carbón mineral.\r\n\r\nEl inicio de la Revolución Industrial fue en Inglaterra dado que ese país presentaba las condiciones económicas, políticas, sociales y tecnológicas necesarias para ese gran cambio. Hacia el siglo XIX, la Revolución Industrial ya era parte de las sociedades de Europa, de Estados Unidos y Japón.',1,1,1),(4,1,'Características de la Revolución Industrial','Que cambios trajo la Revolución Industrial','Entre las principales características de la Revolución Industrial, se destacan:\r\n\r\n1)La producción industrial a gran escala, especialmente de alimentos.\r\n\r\n2)El dominio de la burguesía sobre la economía y la política, sustituyendo el poder absoluto de la nobleza y dando origen a la clase social del proletariado.\r\n\r\n3)El desarrollo de nuevas industrias como la textil, la siderúrgica (metales) o la minera.\r\n\r\n4)La sustitución del hierro por el acero, un material más duro y resistente.\r\n\r\n5)El desarrollo del comercio a nivel mundial (debido a la gran capacidad de producción y a las innovaciones en el transporte por tierra y marítimo).',1,2,1),(5,1,'Inventos clave de la Revolución Industrial','Principales inventos de la Revolucion Industrial','Las tecnologías aplicadas a la producción marcaron un cambio radical para las industrias, debido a que el trabajo manual fue reemplazado por la fabricación en serie. Son invenciones clave que desencadenar la revolución fueron:\r\n\r\n1)La máquina de vapor. Patentada en 1769 por James Watt (Escocia), resultó el invento más importante de la Revolución industrial. Los primeros usos fueron en el transporte (permitió fomentar el comercio), la industria textil (permitió realizar producción en serie a través de maquinarias) y la metalúrgica (permitió trabajar el hierro y el acero para elaborar transportes y maquinarias industriales).\r\n\r\n2)El alumbrado público a gas. La instalación de lámparas a gas en las calles revolucionó a las ciudades, que se convirtieron en lugares más seguros para transitar al estar iluminadas en horarios en los que ya no había luz solar. A fines del período de la Revolución Industrial, las ciudades se habían transformado y las poblaciones se habían duplicado o triplicado.',3,3,1);
/*!40000 ALTER TABLE `puntos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respuestasalumno`
--

DROP TABLE IF EXISTS `respuestasalumno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `respuestasalumno` (
  `RespuestaAlumnoId` int NOT NULL AUTO_INCREMENT,
  `IntentoId` int NOT NULL,
  `PreguntaId` int NOT NULL,
  `OpcionId` int NOT NULL,
  `Tiempo` int NOT NULL,
  PRIMARY KEY (`RespuestaAlumnoId`),
  KEY `IntentoId` (`IntentoId`),
  KEY `PreguntaId` (`PreguntaId`),
  KEY `OpcionId` (`OpcionId`),
  CONSTRAINT `respuestasalumno_ibfk_1` FOREIGN KEY (`IntentoId`) REFERENCES `intentos` (`IntentoId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `respuestasalumno_ibfk_2` FOREIGN KEY (`PreguntaId`) REFERENCES `preguntas` (`PreguntaId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `respuestasalumno_ibfk_3` FOREIGN KEY (`OpcionId`) REFERENCES `opciones` (`OpcionId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Esta tabla guarda los intentos ,las preguntas ,las respuestas\r\n	y el tiempo que ha tardado en hacerlas el alumno ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respuestasalumno`
--

LOCK TABLES `respuestasalumno` WRITE;
/*!40000 ALTER TABLE `respuestasalumno` DISABLE KEYS */;
/*!40000 ALTER TABLE `respuestasalumno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temas`
--

DROP TABLE IF EXISTS `temas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temas` (
  `TemaId` int NOT NULL AUTO_INCREMENT,
  `Titulo` varchar(100) NOT NULL,
  `Resumen` text NOT NULL,
  `ProfesorId` int NOT NULL,
  `MateriaId` int NOT NULL,
  `NivelId` int NOT NULL,
  `FechaCreacion` date NOT NULL,
  `EsActivo` tinyint(1) NOT NULL,
  `Numero` int NOT NULL,
  `Orden` int NOT NULL,
  PRIMARY KEY (`TemaId`),
  KEY `ProfesorId` (`ProfesorId`),
  KEY `MateriaId` (`MateriaId`),
  KEY `NivelId` (`NivelId`),
  CONSTRAINT `temas_ibfk_1` FOREIGN KEY (`ProfesorId`) REFERENCES `profesores` (`ProfesorId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `temas_ibfk_2` FOREIGN KEY (`MateriaId`) REFERENCES `materias` (`MateriaId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `temas_ibfk_3` FOREIGN KEY (`NivelId`) REFERENCES `niveles` (`NivelId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Esta tabla contiene el nombre,resumen numero de tema ,\r\n	la materia a la que corresponde,el profesor que la imparte ,\r\n	el nivel,cuando se creo y el orden el que se tiene que mostrar\r\n	cada tema';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temas`
--

LOCK TABLES `temas` WRITE;
/*!40000 ALTER TABLE `temas` DISABLE KEYS */;
INSERT INTO `temas` VALUES (1,'La Revolución Industrial','Los cambios que transformaron la forma de vivir y producir en Inglaterra a mediados del siglo XIX',1,1,1,'2020-02-18',1,2,3),(2,'La Revolción Francesa','La Francia de 1799 era totalmente distinta a la de 1789. En apenas una década, la Revolución había creado un estado completamente nuevo. De una monarquía absolutista se había pasado a una república. Ya no había súbditos, sino ciudadanos. La sociedad, antes capitaneada por aristocracia y clero, tenía ahora en la burguesía su motor principal. Tan irreconocible estaba la nación y tan ori­ginal era el modo en que se había organizado que hubo de remontarse a la Roma clásica para dar nombre a sus nuevas instituciones: Senado, Consulado, Tribunado, Prefectura...\r\n\r\nLas leyes y la economía, el arte y la ciencia, la educación, el ejército, el papel de la Iglesia, la administración territorial... todos los aspectos del estado habían cambiado respecto del Antiguo Régimen. E, inevitablemente, el modelo de esta renovación integral se tomó como ejemplo en aquellas otras latitudes en que también se perseguía la soberanía del pueblo en los asuntos colectivos, la libertad política y la igualdad ante la ley. Francia estaba de estreno tras el vendaval revolucionario y el mundo la miraba fascinado.',1,1,1,'2020-06-04',1,1,1),(3,'La Primera Guerra Mundial','El primer gran Conflicto del siglo XX;que duro desde 1914 hasta 918 y supuso un cambio en el mapa realizado en el congreso de Viena en 1815 y donde se usaron por primera vez armas quimicas',1,1,1,'2020-06-09',1,7,7);
/*!40000 ALTER TABLE `temas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-14 14:20:29

import sys,os
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QWidget, QApplication,QFileDialog, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
from PyQt5 import QtCore




class Ventana_Accion(QDialog,QPushButton):
    def __init__(self):
        QDialog.__init__(self)
        QLabel.__init__(self)
       self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        
        
    def Cargar_Archivo(self):
        self.Nombre_Archivo.setText("Aqui Aparecerá el archivo seleccionado")
        if(self.CSV_Format.isChecked()):
            options = QFileDialog.Options()
            options |= QFileDialog.DontUseNativeDialog
            self.fileName, _ = QFileDialog.getOpenFileName(
                self, "QFileDialog.getOpenFileName()", "", "CSVFilesFiles(*.csv)")
            if self.fileName:
                self.Archivo_Elegido=self.Nombre_Archivo.setText(self.fileName)
                
                
            else:
                QMessageBox.warning(self,"Vacio","Tienes que cargar un archivo para ver gráficos",QMessageBox.Discard)
                
        elif(self.Excel_Format.isChecked()):
            options = QFileDialog.Options()
            options |= QFileDialog.DontUseNativeDialog
            self.fileName, _ = QFileDialog.getOpenFileName(
                self, "QFileDialog.getOpenFileName()", "", "ExcelFilesFiles(*.xlsx *.xls)")
            
            if self.fileName:
                if self.fileName:
                    self.Archivo_Elegido=self.Nombre_Archivo.setText(self.fileName).text()
               
                
                
        else:
            QMessageBox.warning(self,"ERROR","Necesitas seleccionar un foramto de archivo",QMessageBox.Discard)
            
    def Hacer_Graficos(self):
        # self.Archivo_Elegido=self.Nombre_Archivo.setText(self.fileName).text()
        
        if(self.Nombre_Archivo.text()=="Aqui Aparecerá el archivo seleccionado"):
            QMessageBox.warning(self,"Vacio","Tienes que cargar un archivo para ver gráficos",QMessageBox.Discard)
            
        else:
            from Generar_Dibujo import Obtein_Result
            
            Llevar=Obtein_Result()
            Llevar.exec_()
            
if __name__ == '__main__':
    programa = QApplication(sys.argv)
    Opciones_Archivo = Ventana_Accion()
    Opciones_Archivo.show()
    programa.exec_()

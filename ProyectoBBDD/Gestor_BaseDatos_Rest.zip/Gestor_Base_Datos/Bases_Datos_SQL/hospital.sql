-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: hospital
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `hospital`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `hospital` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `hospital`;

--
-- Table structure for table `atienden`
--

DROP TABLE IF EXISTS `atienden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `atienden` (
  `DNI_Paciente` varchar(10) NOT NULL,
  `Cod_Enfermero` int NOT NULL,
  `Num_Pacientes_Atiende` int DEFAULT NULL,
  KEY `DNI_Paciente` (`DNI_Paciente`),
  KEY `Cod_Enfermero` (`Cod_Enfermero`),
  CONSTRAINT `atienden_ibfk_1` FOREIGN KEY (`DNI_Paciente`) REFERENCES `pacientes` (`DNI_Paciente`),
  CONSTRAINT `atienden_ibfk_2` FOREIGN KEY (`Cod_Enfermero`) REFERENCES `enfermeros` (`Cod_Enfermero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `atienden`
--

LOCK TABLES `atienden` WRITE;
/*!40000 ALTER TABLE `atienden` DISABLE KEYS */;
/*!40000 ALTER TABLE `atienden` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `camas_ocupadas`
--

DROP TABLE IF EXISTS `camas_ocupadas`;
/*!50001 DROP VIEW IF EXISTS `camas_ocupadas`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `camas_ocupadas` AS SELECT 
 1 AS `Num_Habitacion`,
 1 AS `Num_Camas`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `enfermeros`
--

DROP TABLE IF EXISTS `enfermeros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `enfermeros` (
  `Cod_Enfermero` int NOT NULL,
  `Nombre_Enfermero` varchar(20) NOT NULL,
  `Cod_Planta` int NOT NULL,
  PRIMARY KEY (`Cod_Enfermero`),
  KEY `Cod_Planta` (`Cod_Planta`),
  CONSTRAINT `enfermeros_ibfk_1` FOREIGN KEY (`Cod_Planta`) REFERENCES `plantas` (`Cod_Planta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enfermeros`
--

LOCK TABLES `enfermeros` WRITE;
/*!40000 ALTER TABLE `enfermeros` DISABLE KEYS */;
/*!40000 ALTER TABLE `enfermeros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `habitaciones`
--

DROP TABLE IF EXISTS `habitaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `habitaciones` (
  `Num_Habitacion` int NOT NULL,
  `Num_Camas` int DEFAULT NULL,
  `Cod_Planta` int NOT NULL,
  `Cod_Cama` int NOT NULL,
  PRIMARY KEY (`Num_Habitacion`),
  KEY `Cod_Planta` (`Cod_Planta`),
  CONSTRAINT `habitaciones_ibfk_1` FOREIGN KEY (`Cod_Planta`) REFERENCES `plantas` (`Cod_Planta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `habitaciones`
--

LOCK TABLES `habitaciones` WRITE;
/*!40000 ALTER TABLE `habitaciones` DISABLE KEYS */;
INSERT INTO `habitaciones` VALUES (101,3,1,1),(102,1,1,2);
/*!40000 ALTER TABLE `habitaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicos`
--

DROP TABLE IF EXISTS `medicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicos` (
  `Num_Colegiado` int NOT NULL,
  `Nombre_Medico` varchar(20) NOT NULL,
  `Num_Pacientes_Tratados` int DEFAULT NULL,
  `DNI_paciente` varchar(10) NOT NULL,
  PRIMARY KEY (`Num_Colegiado`),
  KEY `DNI_paciente` (`DNI_paciente`),
  CONSTRAINT `medicos_ibfk_1` FOREIGN KEY (`DNI_paciente`) REFERENCES `pacientes` (`DNI_Paciente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicos`
--

LOCK TABLES `medicos` WRITE;
/*!40000 ALTER TABLE `medicos` DISABLE KEYS */;
INSERT INTO `medicos` VALUES (250,'Doctor Bacterio',4,'14443D'),(2503,'Doctor Bacterio',4,'015655W');
/*!40000 ALTER TABLE `medicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pacientes`
--

DROP TABLE IF EXISTS `pacientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pacientes` (
  `DNI_Paciente` varchar(10) NOT NULL,
  `Num_SS_Paciente` varchar(12) NOT NULL,
  `Nombre_Paciente` varchar(20) NOT NULL,
  `Diagnostico` varchar(250) NOT NULL,
  `Tratamiento` varchar(100) NOT NULL,
  `Num_Habitacion` int NOT NULL,
  `Cod_Cama` int NOT NULL,
  PRIMARY KEY (`DNI_Paciente`),
  UNIQUE KEY `Num_SS_Paciente` (`Num_SS_Paciente`),
  KEY `Num_Habitacion` (`Num_Habitacion`),
  CONSTRAINT `pacientes_ibfk_1` FOREIGN KEY (`Num_Habitacion`) REFERENCES `habitaciones` (`Num_Habitacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pacientes`
--

LOCK TABLES `pacientes` WRITE;
/*!40000 ALTER TABLE `pacientes` DISABLE KEYS */;
INSERT INTO `pacientes` VALUES ('015655W','abcdesg','Pepe','Fractura de codo','Calamates cada 6 horas',101,1),('14443D','adfedf','Paco','Insuficiencia Respiratoria','Oxigeno asistido',102,2);
/*!40000 ALTER TABLE `pacientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plantas`
--

DROP TABLE IF EXISTS `plantas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plantas` (
  `Cod_Planta` int NOT NULL,
  `Especialidad` varchar(20) NOT NULL,
  PRIMARY KEY (`Cod_Planta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plantas`
--

LOCK TABLES `plantas` WRITE;
/*!40000 ALTER TABLE `plantas` DISABLE KEYS */;
INSERT INTO `plantas` VALUES (1,'Traumatologia'),(2,'Neumologia'),(3,'Urgencias');
/*!40000 ALTER TABLE `plantas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `hospital`
--

USE `hospital`;

--
-- Final view structure for view `camas_ocupadas`
--

/*!50001 DROP VIEW IF EXISTS `camas_ocupadas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `camas_ocupadas` AS select `habitaciones`.`Num_Habitacion` AS `Num_Habitacion`,`habitaciones`.`Num_Camas` AS `Num_Camas` from `habitaciones` group by `habitaciones`.`Num_Habitacion` having (`habitaciones`.`Num_Camas` > 0) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-11 11:08:17

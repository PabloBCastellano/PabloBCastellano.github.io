import urllib.request
import urllib.parse
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
from PyQt5 import QtCore
import json
import collections
import requests
from urllib.request import urlopen
from Actualizar_Usuario_Rest import *


class Usuarios_Registrados(QDialog, QPushButton):
    def __init__(self):
        QDialog.__init__(self)
        QLabel.__init__(self)

        uic.loadUi("Usuarios_Registrados.ui", self)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, True)
        self.setWindowTitle("Detalles del Usuario")
        self.EndPointVerUsuario_WebServiceRest()

    def EndPointVerUsuario_WebServiceRest(self):
        try:
            url = 'http://localhost:9090/segundoproyecto/api/UsuariosRegistrados'
            response = urlopen(url)
            string = response.read().decode('utf-8')
            json_obj = json.loads(string)
            dic_personas = {}

            for each in range(len(json_obj)):
                dic_personas[json_obj[each]['dni']] = {"Nombre": json_obj[each]["nombre"], "Apellidos": json_obj[
                    each]["apellidos"], "Edad": json_obj[each]["edad"], "Sexo": json_obj[each]["sexo"]}
            # self.Usuarios.setSizeAdjustPolicy(
            # QWidget.QAbstractScrollArea.AdjustToContents)
            # self.Usuarios.resizeColumnsToContents()
            self.Usuarios.setRowCount(len(dic_personas))
            self.Usuarios.setColumnCount(5)
            row = 0
            # for each in dic_personas.items():
            #    print(each)
            for each, val in dic_personas.items():
                # print(dic_personas[each]["Nombre"])
                # self.Usuarios.addItem("DNI: "+each+"  Nombre:"+str(dic_personas[each]["Nombre"]) +
                #                      "  Apellidos:"+str(dic_personas[each]["Apellidos"]) +
                #                      "  Edad:"+str(dic_personas[each]['Edad']) +
                #                      "   Sexo:"+str(dic_personas[each]['Sexo']))
                self.Usuarios.setHorizontalHeaderLabels(
                    ["DNI Usuario", "Nombre Usuario", "Apellidos Usuarios", "Edad", "Sexo"])
                self.Usuarios.setItem(row, 0, QTableWidgetItem(str(each)))
                self.Usuarios.setItem(row, 1, QTableWidgetItem(
                    str(dic_personas[each]["Nombre"])))
                self.Usuarios.setItem(row, 2, QTableWidgetItem(
                    str(dic_personas[each]["Apellidos"])))
                self.Usuarios.setItem(row, 3, QTableWidgetItem(
                    str(dic_personas[each]["Edad"])))
                self.Usuarios.setItem(row, 4, QTableWidgetItem(
                    str(dic_personas[each]["Sexo"])))

                row += 1
        except:
            QMessageBox.warning(
                self, "ERROR", "NO SE HA PODIDO REALIZAR LA CONEXION CON EL WEB SERVICE.VERIFIQUE LA CONEXIÓN", QMessageBox.Discard)

    def Mostrar_click(self):

        fila = self.Usuarios.currentRow()
        Dni_Usuario = self.Usuarios.item(fila, 0).text()
        self.close()
        Actualizar = Usuario_Cambiar(Dni_Usuario)
        Actualizar.exec_()


if __name__ == '__main__':
    programa = QApplication(sys.argv)
    validar = Usuarios_Registrados()
    validar.show()
    programa.exec_()

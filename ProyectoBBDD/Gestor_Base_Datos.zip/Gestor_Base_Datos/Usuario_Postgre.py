import sys
import os
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from PyQt5.QtWidgets import QApplication, QLabel, QWidget, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon
from PyQt5 import uic
# conn = psycopg2.connect(user="Pablo", password="rootroot",database="postgres")


class Inicio_Postgre(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        uic.loadUi("Usuario_Postgre.ui", self)
        self.setWindowTitle("Inicio de Sesión PostgreSQL")

    def Activar_Bases(self):
        self.List_DB.clear()
        self.Nombre_Acceso = self.Name_User.text()
        self.Clave_Acceso = self.Pass_User.text()
        self.database = "postgres"

        try:
            self.conn = psycopg2.connect(
                user=self.Nombre_Acceso, password=self.Clave_Acceso, database=self.database)
            self.cursor = self.conn.cursor()
            self.cursor.execute("SELECT datname FROM pg_database")
            self.resultado = self.cursor.fetchall()
            if(self.resultado != []):
                for each in self.resultado:
                    self.List_DB.addItem(str(each).replace(
                        "('", "").replace("',)", ""))
        except (psycopg2.OperationalError, NameError):
            QMessageBox.warning(
                self, "DATOS INCORRECTOS", "El usuario/contraseña son incorrectos", QMessageBox.Discard)

    def Terminar(self):
        try:
            self.close()
        except psycopg2.OperationalError:
            pass

    def Validar(self):
        self.Nombre_Acceso = self.Name_User.text()
        self.Clave_Acceso = self.Pass_User.text()
        self.Seleccion = self.List_DB.selectedItems()
        self.Database = []
        for each in range(len(self.Seleccion)):
            self.Database.append(self.List_DB.selectedItems()[each].text())
        if(self.Database == []):
            self.Database.append('postgres')
            print("Hola "+self.Nombre_Acceso+" y tienes la clave " +
                  self.Clave_Acceso + " y la base de datos "+str(self.Database[0]))
            self.close()
        else:
            self.Database = str(self.Database[0])
            self.close()
        try:
            self.conn.close()
        except AttributeError:
            self.close()


if __name__ == '__main__':
    programa = QApplication(sys.argv)
    validar = Inicio_Postgre()
    validar.show()
    programa.exec_()

import sys
import os
import pandas as pd
from pytrends.request import TrendReq
from PyQt5.QtGui import QFont
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
import time
import datetime
from pandas import DataFrame


class Palabra_Aparece(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        QLabel.__init__(self)

        uic.loadUi("Palabra_Buscar.ui", self)

    def Rellenar_Tabla(self):

        self.Fecha_actual = datetime.datetime.now()

        self.pytrend = TrendReq()
        try:
            self.Estadisticas.clear()

            self.Texto_Buscar = self.Texto_Entrada.text()
            self.pytrend.build_payload(kw_list=[self.Texto_Buscar])
            self.df = self.pytrend.interest_by_region()
            self.records = self.df.to_records(index=True)
            self.Encabezado = list(pd.DataFrame(self.records))
            # for cols in self.Encabezado:
                # print(cols)
            # print(str(self.records).replace("[(", "").replace("(", "\n").replace(
            # ", '') (", ",").replace(", '')", "").replace(", '')]", ""))

            # for each in self.records:
                # print(str(each).replace(", '')", ")"))

            self.Estadisticas.setRowCount(len(self.records))
            self.Estadisticas.setColumnCount(len(self.records[0]))
            row = 0

            for each in self.records:

                for val in range(len(each)):
                    self.Estadisticas.setItem(
                        row, val, QTableWidgetItem(str(each[val])))

                row += 1
                self.Estadisticas.setHorizontalHeaderLabels(self.Encabezado)
        except:
            self.Estadisticas.setHorizontalHeaderLabels(["", ""])
            QMessageBox.warning(self, "ERROR", "Necesitas introducir una palabra para saber el Numero de veces que se ha buscado ",
                                QMessageBox.Discard)


if __name__ == '__main__':
    programa = QApplication(sys.argv)
    Generar_Informacion = Palabra_Aparece()
    Generar_Informacion.show()
    programa.exec_()

import os
usuario = 'sa'
clave = 'rootroot'
salida = []
dir_actual = (os.getcwd()+(str('\\')))
print(dir_actual)
Carpeta_Seguridad = "Bases_Datos_SQLSERVER"
Encontrar = 0
for each in(os.listdir()):
    if(each == Carpeta_Seguridad):
        Encontrar = 1
        break

    else:
        Encontrar = 0

if(Encontrar == 0):
    os.mkdir(str(dir_actual)+Carpeta_Seguridad, 777)
else:
    pass

os.chdir(dir_actual+str(Carpeta_Seguridad))
Nuevo_Directorio = (os.getcwd()+str('\\'))
print("Directorio nuevo "+Nuevo_Directorio)
bases_Datos = ['Ejemplo1','Mundo']

for each in range(len(bases_Datos)):
    guardar = str(bases_Datos[each])
    os.system("sqlcmd -S localhost -U "+str(usuario)+" -P "+str(clave)+" -Q \"BACKUP DATABASE ["+str(guardar)+"] TO DISK = N'"+str(
        Nuevo_Directorio)+str(guardar)+".bak' WITH NOFORMAT, NOINIT, NAME = 'demodb-full', SKIP, NOREWIND, NOUNLOAD, STATS = 10\"")
    os.system("sqlcmd -S localhost -U "+str(usuario)+" -P "+str(clave)+" -Q \"BACKUP LOG ["+str(guardar)+"] TO DISK = N'"+str(
        Nuevo_Directorio)+str(guardar)+".bak' WITH NOFORMAT, NOINIT, NAME = N'demodb_LogBackup', NOSKIP, NOREWIND, NOUNLOAD, STATS = 5\"")

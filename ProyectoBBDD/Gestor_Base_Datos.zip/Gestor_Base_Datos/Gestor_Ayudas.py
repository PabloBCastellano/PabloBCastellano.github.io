import os
import sys
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QWidget, QApplication, QTextBrowser, QLabel, QDialog, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
import pyperclip


class Ventana_Ayuda(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        uic.loadUi("Panel_Ayuda.ui", self)
        self.setWindowTitle("Panel de Ayuda")

    def Crear_Base_Datos(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Create database Nombre_Base_Datos")

    def Activar_Base_Datos(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Use Nombre_Base")

    def Borrar_Base_Datos(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Drop database Nombre_Base_Datos")

    def Listar_Base_Datos(self):
        self.Ayuda.clear()
        self.Ayuda.setText("show databases")

    def Crear_Nueva_Tabla(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "Create table Nombre_Tabla(\n"
            + "\t Campo1 Tipo(maxvalor permitido) indicar si es \n \tauto incremento incremental  si puede ser nulo ,\n"
            + "\t Campo2 Tipo(maxvalor permitido) si puede ser nulo,\n"
            + "\t si hay clave/s primarias primary key(indicar cual/cuales son))"
            + "\t engine='Innodb'")

    def Ver_Tablas_Existentes(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Show tables")

    def Describir_Tablas(self):
        self.Ayuda.clear()
        self.Ayuda.setText("describe Nombre_Tabla")

    def Insertar_Datos(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "insert into Nombre_Tabla(indicar campos)values\n"
            + "\t (campo1,campo2,campo3),\n"
            + "\t (campon1,campon2,campo3)")

    def Cambiar_Datos(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "update Nombre_Tabla set campo=nuevo_valor where condicion/es")

    def Borrar_Registro(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "delete from Nombre_Tabla where condicion/es")

    def Filtrar_Tabla(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "select all/campos_mostrar from Nombre_Tabla where Condicion/es limit numRegistros order by campo asc/desc")

    def Quitar_Tabla(self):
        self.Ayuda.clear()
        self.Ayuda.setText("drop table Nombre_Tabla")

    def Vaciar_Tabla(self):
        self.Ayuda.clear()
        self.Ayuda.setText("truncate Nombre_Tabla")

    def Nueva_Vista(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "Create view Nombre_Vista as select all/campos_mostrar from Nombre_Tabla where Condicion/es limit numRegistros order by campo asc/desc")

    def Eliminar_Vista(self):
        self.Ayuda.clear()
        self.Ayuda.setText("drop view Nombre_Vista")

    def Vistas_Existentes(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "SHOW FULL TABLES IN database_name WHERE TABLE_TYPE LIKE 'VIEW';")

    def Crear_Procedimiento(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "create procedure nombre_Procedimiento \n"
            + "\t (in/out parametro1 tipo(maxima_extension),\n \t parametro2 tipo(maxima_extension)) \n"
            + "\t Alias_Procedimiento:begin \n"
            + "\t declare variable1 tipo(maxima_extension);\n"
            + "\t declare variable2 tipo(maxima_extension);\n"
            + "\t set variable1=(select all/campos_mostrar from Nombre_Tabla where \n\t Condicion/es limit numRegistros order by campo asc/desc);\n"
            + "\t set variable2=(select all/campos_mostrar from Nombre_Tabla where \n\t Condicion/es limit numRegistros order by campo asc/desc);\n"
            + "\t Condicion/es \n"
            + "\t para terminar dentro de una condicion leave Alias_Procedimiento \n"
            + "\t end if;\n "
            + "\t Commit; \n"
            "end")

    def Llamar_Procedimiento(self):
        self.Ayuda.clear()
        self.Ayuda.setText("call nombre_Procedimiento")

    def Ver_Procedimientos_Existentes(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "Show procedure status o show procedure status where db=Nombre_Base")

    def Eliminar_Procedimiento(self):
        self.Ayuda.clear()
        self.Ayuda.setText("drop procedure nombre_Procedimiento")

    def Nueva_Funcion(self):
        self.Ayuda.clear()
        self.Ayuda.setText("create Function nombre_Funcion(\n"
                           + "\t parametro1 tipodato(maxima extension),\n"
                           + "\t parametro2 tipodato(maxima_extension)) \n"
                           + "\t returns tipodato \n"
                           + "\t deterministic / reads sql data \n"
                           + "begin \n"
                           + "\t declare variable1 tipodato(maxima_extension); \n"
                           + "\t declare variable2 tipodato(maxima_extension); \n"
                           + "\t set variable1=(select all/campos_mostrar from Nombre_Tabla where \n\t Condicion/es limit numRegistros order by campo asc/desc) ;\n"
                           + "\t set variable2=(select all/campos_mostrar from Nombre_Tabla where \n\t Condicion/es limit numRegistros order by campo asc/desc) ;\n"
                           + "\t Condicion/es ;\n"
                           + "\t return variable/s ; \n"
                           + "end ;"
                           )

    def Funciones_Existentes(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "Show function status o show function status where db=Nombre_Base")

    def Llamar_Funcion(self):
        self.Ayuda.clear()
        self.Ayuda.setText("select Nombre_Funcion(parametros si hay)")

    def Eliminar_Funcion(self):
        self.Ayuda.clear()
        self.Ayuda.setText("drop function Nombre_Funcion")

    def Crear_Trigger(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Create Trigger Nombre_Trigger before/after insert/update/delete on Nombre_Tabla \n"
                           + "\t for each row \n"
                           + "begin \n"
                           + "\t declare variable1 tipodato(maxima_extension);\n"
                           + "\t declare variable2 tipodato(maxima_extension);\n"
                           + "\t set variable1=(select all/campos_mostrar from Nombre_Tabla where \n\t Condicion/es limit numRegistros order by campo asc/desc);\n"
                           + "\t set variable2=(select all/campos_mostrar from Nombre_Tabla where \n\t Condicion/es limit numRegistros order by campo asc/desc);\n"
                           + "\t condicion/es \n"
                           + "end"
                           )

    def Eliminar_Trigger(self):
        self.Ayuda.clear()
        self.Ayuda.setText("drop Trigger Nommbre_Trigger")

    def Ver_Triggers_Existentes(self):
        self.Ayuda.clear()
        self.Ayuda.setText("show triggers from Nombre_Base_Datos")

    def Enviar_Portapapeles(self):
        self.Portapapeles = self.Ayuda.toPlainText()
        pyperclip.copy(self.Portapapeles)
        self.close()

    def Nuevo_Usuario_SQL(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "create user 'Nombre_Usuario'@'localhost' identified by 'tu_clave'")

    def Asignar_Privilegios_SQL(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Grant \n"
                           + "\t ALL PRIVILEGES\n"
                           + "\t CREATE\n"
                           + "\t DROP\n"
                           + "\t DELETE\n"
                           "\t INSERT\n"
                           + "\t SELECT\n"
                           + "\t UPDATE\n"
                           + "\t GRANT OPTION\n"
                           + "on Nombre_Base.Nombre_Tabla to 'Nombre_Usuario'@'localhost")

    def Revokar_Privilegios_SQL(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Revoke \n"
                           + "\t ALL PRIVILEGES\n"
                           + "\t CREATE\n"
                           + "\t DROP\n"
                           + "\t DELETE\n"
                           + "\t INSERT\n"
                           + "\t SELECT\n"
                           + "\t UPDATE\n"
                           + "\t GRANT OPTION\n"
                           + "on Nombre_Base.Nombre_Tabla from 'Nombre_Usuario'@'localhost'")

    def Quitar_Usuario_SQL(self):
        self.Ayuda.clear()
        self.Ayuda.setText("drop user 'Nombre_Usuario'@'localhost'")

    def Listar_Usuarios_SQL(self):
        self.Ayuda.clear()
        self.Ayuda.setText("select User from mysql.user")

    def Nuevo_Usuario_Firebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Create User Nombre_Usuario password 'clave'")

    def Quitar_Usuario_Firebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText("drop user Nombre_Usuario")

    def Asignar_Privilegios_Firebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "grant\n"
            + "\t all\n"
            + "\t create table\n"
            + "\t select\n"
            + "\t insert\n"
            + "\t update\n"
            + "\t delete\n"
            + "\t Execute on Procedure Nombre_Procedimiento\n"
            + "on Nombre_Tabla To Nombre_Usuario\n"
            + "\t opcionalmente with grant option")

    def Revokar_Privilegios_Firebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "revoke\n"
            + "\t all\n"
            + "\t create table\n"
            + "\t select\n"
            + "\t insert\n"
            + "\t update\n"
            + "\t delete\n"
            + "\t Execute on Procedure Nombre_Procedimiento\n"
            + "on Nombre_Tabla from Nombre_Usuario\n ")

    def Listar_Usuarios_Firebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "SELECT DISTINCT RDB$USER FROM RDB$USER_PRIVILEGES")

    def Nuevo_Usuario_Server(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "create Login Nombre_Usuario with Password='contraseña'\n"
            + "create User Nombre_Usuario for Login Nombre_Usuario")

    def Quitar_Usuario_Server(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "DROP LOGIN Nombre_Sesion\n"
            + "DROP USER Nombre_Usuario")

    def Asignar_Privilegios_Server(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Use Nombre_Base\n"
                           "Grant \n"
                           + "\t all\n"
                           + "\t insert\n"
                           + "\t delete\n"
                           + "\t select\n"
                           + "\t update\n"
                           + "\t Execute on Nombre_Procedimiento/Nombre_Funcion\n"
                           + "on schema/Object::Nombre to Nombre_Usuario\n"
                           + "\t opcionalmente with grant option")

    def Revokar_Privilegios_Server(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Use Nombre_Base\n"
                           + "revoke\n"
                           + "\t all\n"
                           + "\t insert\n"
                           + "\t delete\n"
                           + "\t select\n"
                           + "\t update\n"
                           + "\t Execute on Nombre_Procedimiento/Nombre_Funcion\n"
                           + "on schema/Object::Nombre from  Nombre_Usuario\n")

    def Listar_Usuarios_Server(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "SELECT name, type_desc FROM sys.server_principals WHERE type_desc IN('SQL_LOGIN', 'WINDOWS_LOGIN', 'WINDOWS_GROUP')")

    def Nuevo_Usuario_Postgre(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "create user NombreUsuario with password 'clave usuario'")

    def Quitar_Usuario_Postgre(self):
        self.Ayuda.clear()
        self.Ayuda.setText("drop user NombreUsuario")

    def Asignar_Privilegios_Postgre(self):
        self.Ayuda.clear()
        self.Ayuda.setText("grant\n"
                           + "\t connecto on Nombre_Base \n"
                           + "\t all privileges \n"
                           + "\t insert \n"
                           + "\t update \n"
                           + "\t delete \n"
                           + "\t trigger on NombreTrigger \n"
                           + "\t truncate on Nombre_Tabla \n"
                           + "\t execute on Nombre_Procedimiento/Nombre_Funcion \n"
                           + "to NombreUsuario opcionalmente with grant option")

    def Revokar_Privilegios_Postgre(self):
        self.Ayuda.clear()
        self.Ayuda.setText("revoke \n"
                           + "\t grant option for privilegios on NombreBase/Table \n"
                           + "\t all privileges \n"
                           + "\t insert \n"
                           + "\t update \n"
                           + "\t delete \n"
                           + "\t trigger on NombreTrigger \n"
                           + "\t truncate on Nombre_Tabla \n"
                           + "\t execute on Nombre_Procedimiento/Nombre_Funcion \n"
                           + "from NombreUsuario \n")

    def Listar_Usuarios_Postgre(self):
        self.Ayuda.clear()
        self.Ayuda.setText('SELECT u.usename AS "User name",'
                           + 'u.usesysid AS "User ID",\n'
                           + '\t CASE WHEN u.usesuper AND u.usecreatedb THEN CAST( \n'
                           + "\t 'superuser, create database' AS pg_catalog.text ) \n"
                           + "\t WHEN u.usesuper THEN CAST('superuser' AS\n"
                           + "\t pg_catalog.text)\n"
                           + "\t WHEN u.usecreatedb THEN CAST(\n"
                           + "\t 'create database' AS pg_catalog.text)\n"
                           + "\t ELSE CAST('' AS pg_catalog.text) \n"
                           + '\t END AS "Attributes" \n'
                           + "FROM pg_catalog.pg_user u ORDER BY 1 desc")

    def Listar_Base_DatosServer(self):
        self.Ayuda.clear()
        self.Ayuda.setText("select name from sys.databases")

    def Listar_Base_DatosPostgre(self):
        self.Ayuda.clear()
        self.Ayuda.setText("SELECT datname FROM pg_database")

    def Crear_Base_Datos_Firebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "Create database '[ruta]Nombre_Base_Datos.fdb' user 'NombreUsuario' password 'clave'")

    def Crear_Nueva_TablaNoEngine(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "Create table Nombre_Tabla(\n"
            + "\t Campo1 Tipo(maxvalor permitido) indicar si es \n \tauto incremento incremental  si puede ser nulo ,\n"
            + "\t Campo2 Tipo(maxvalor permitido) si puede ser nulo,\n"
            + "\t si hay clave/s primarias primary key(indicar cual/cuales son))")

    def Ver_Tablas_ExistentesSQLITE(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "select distinct name,type from sqlite_master where type='table' or type='procedure' or type='view' ")

    def Describir_TablasSQLITE(self):
        self.Ayuda.clear()
        self.Ayuda.setText("PRAGMA table_info(nombretabla)")

    def Ver_Tablas_ExistentesFBD(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "SELECT RDB$RELATION_NAME FROM RDB$RELATIONS WHERE RDB$SYSTEM_FLAG=0")

    def Describir_TablasFirebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "select rdb$field_name from rdb$relation_fields where rdb$relation_name='NombreTabla'")

    def Ver_Tablas_ExistentesSERVER(self):
        self.Ayuda.clear()
        self.Ayuda.setText("SELECT name from sys.Tables")

    def Describir_TablasServer(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "select  Column_Name,Data_Type FROM   INFORMATION_SCHEMA.Columns where table_name = 'tablename'")

    def Ver_Tablas_ExistentesPostgre(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "Select Tablename from pg_catalog.pg_tables where schemaname != 'pg_catalog' and schemaname != 'information_schema'")

    def Describir_TablasPostgre(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_NAME = 'NombreTabla'")

    def Vistas_ExistentesSQLITE(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "select distinct name,type from sqlite_master where type='view'")

    def Vistas_ExistentesFirebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "SELECT DISTINCT RDB$VIEW_NAME FROM RDB$VIEW_RELATIONS")

    def Vistas_ExistentesSERVER(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "SELECT name FROM sysobjects WHERE xtype = 'V'")

    def Vistas_ExistentesPostgre(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "select  viewname from pg_catalog.pg_views where schemaname != 'pg_catalog' and schemaname != 'information_schema'")

    def Crear_ProcedimientoFirebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Create Procedure Nombre procedimiento(varaible tipo) returns(\n"
                           + "campos a retornar tipo\n"
                           + "as \n "
                           + "\t declare variable nombre tipo\n"

                           + " Begin \n"
                           + "\t condiciones \n"
                           + "suspend; \n"

                           + "\t for sentencia select into :campostabla \n"
                           + "\t do \n"
                           + "\t Begin \n"
                           + "\t\tacciones\n"
                           + "\t\tsuspend;  \n"
                           + "\t end\n"
                           + "end"
                           )

    def Llamar_ProcedimientoFirebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText("select * from NombreProcedimiento ")

    def Ver_Procedimientos_ExistentesFirebird(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            'SELECT rdb$Procedure_name as "Procedure Name" FROM rdb$procedures WHERE rdb$system_flag IS NULL OR rdb$system_flag = 0')

    def Crear_ProcedimientoServer(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "create or alter procedure NombreProcedimiento @Parametro1 tipo,@Parametro2 tipo \n"
            + "as \n"
            + "        declare @Variable1 as tipo_dato; \n"
            + "        declare @Variable2 as tipo_dato; \n"
            + "        set @Variable1=(select all/campos_mostrar from Nombre_Tabla where \n\t Condicion/es limit numRegistros order by campo asc/desc) ;\n"
            + "        set @Variable2=(select all/campos_mostrar from Nombre_Tabla where \n\t Condicion/es limit numRegistros order by campo asc/desc) ;\n"
            + "        Condicion/es\n"
            + "             accion"

        )

    def Llamar_ProcedimientoServer(self):
        self.Ayuda.clear()
        self.Ayuda.setText("Exec NombreProcedimiento @Parametro/s=valor")

    def Ver_Procedimientos_ExistentesServer(self):
        self.Ayuda.clear()
        self.Ayuda.setText(
            "Select Routine_Name from Information_Schema.Routines where Routine_Type = 'Procedure' "
            + " order by Routine_Name")


if __name__ == '__main__':
    programa = QApplication(sys.argv)
    validar = Ventana_Ayuda()
    validar.show()
    programa.exec_()

import os
usuario = 'root'
clave = 'rootroot'
salida = []
dir_actual = (os.getcwd()+(str('\\')))
print(dir_actual)
Carpeta_Seguridad = "Bases_Datos_SQL"
Encontrar = 0
for each in(os.listdir()):
    if(each == Carpeta_Seguridad):
        Encontrar = 1
        break

    else:
        Encontrar = 0

if(Encontrar == 0):
    os.mkdir(str(dir_actual)+Carpeta_Seguridad, 777)
else:
    pass

os.chdir(dir_actual+str(Carpeta_Seguridad))
Nuevo_Directorio = (os.getcwd()+str('\\'))
print("Directorio nuevo "+Nuevo_Directorio)
bases_Datos = ['agenda', 'biblioteca', 'centro_medico', 'seguros', 'world']
for each in range(len(bases_Datos)):
    guardar = bases_Datos[each]
    os.system("mysqldump --user="+str(usuario)+" --password=" +
              str(clave)+" --databases "+str(guardar)+" >"+str(guardar)+".sql")

import csv
import os
import sys
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
from fpdf import FPDF
import io
from PyQt5 import QtCore


class Guardar_Opciones(QDialog):
    def __init__(self, Datos, Cabecera):
        QDialog.__init__(self)
        QPushButton.__init__(self)
        uic.loadUi("Guardar_Consultas.ui", self)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        self.setWindowTitle("Guardar Resultados")
        self.Datos = Datos
        self.Cabecera = Cabecera
        self.separar = str(self.Cabecera).split(",")
        self.Directorio_Actual = (os.getcwd()+(str('\\')))

    def Mostrar(self):
        Encontrar = 0

        print(self.Directorio_Actual)
        Carpeta_Salidas = "Consultas_Guardadas"
        for each in(os.listdir()):
            if(each == Carpeta_Salidas):
                Encontrar = 1
                break
            else:
                Encontrar = 0

        if(Encontrar == 0):
            try:
                os.mkdir(str(self.Directorio_Actual)+Carpeta_Salidas, 777)
            except FileExistsError:
                os.chdir(self.Directorio_Actual+str(Carpeta_Salidas))
                Nuevo_Directorio = (os.getcwd()+str('\\'))
                print(Nuevo_Directorio)

        else:
            pass

        os.chdir(self.Directorio_Actual+str(Carpeta_Salidas))
        Nuevo_Directorio = (os.getcwd()+str('\\'))
        print("Directorio nuevo "+Nuevo_Directorio)
        self.Destino = self.Nombre_Archivo.text()
        print("El archivo se llamará ", self.Destino)

        self.Guardar()

    def Guardar(self):
        if(self.Opcion1.isChecked()):
            self.Escribir_Csv()
        elif(self.Opcion2.isChecked()):
            self.Escribir_Pdf()

        elif(self.Opcion3.isChecked()):
            self.Escribir_HTML()

    def Escribir_Pdf(self, spacing=5):
        try:
            os.remove(self.Destino+".pdf")
        except FileNotFoundError:
            pass

        try:
            pdf = FPDF()
            pdf.set_font("Arial", size=11)
            pdf.add_page()

            col_width = int((pdf.w)/len(self.separar))
            row_height = pdf.font_size

            for row in self.Cabecera:
                for item in row:
                    pdf.cell(col_width, row_height*spacing,
                             txt=str(item), border=1)
                pdf.ln(row_height*spacing)

            for row in self.Datos:
                for item in row:
                    pdf.cell(col_width, row_height*spacing,
                             txt=str(item), border=1)
                pdf.ln(row_height*spacing)

            pdf.output(self.Destino+'.pdf')
            QMessageBox.information(
                self, "OPERACIÓN REALIZADA", "Datos de la consulta exportados "+self.Opcion2.text(), QMessageBox.Ok)

            os.chdir(self.Directorio_Actual)
        except Exception as Error:
            print(str(Error))

    def Escribir_Csv(self):
        # Abrimos el ficher csv

        try:
            with open(self.Destino+".csv", "a", newline="", encoding='ISO-8859-1')as titular:
                escribir = csv.writer(titular, delimiter=";")
                escribir.writerows(self.Cabecera)

            with open(self.Destino+".csv", "a", newline="", encoding='ISO-8859-1')as linea:
                escribir = csv.writer(linea, delimiter=";")
            # Escribimos la fila completa
                escribir.writerows(self.Datos)

            QMessageBox.information(
                self, "OPERACIÓN REALIZADA", "Datos de la consulta exportados "+self.Opcion1.text(), QMessageBox.Ok)

            os.chdir(self.Directorio_Actual)

        except UnicodeEncodeError:
            pass

    def Escribir_HTML(self):
        try:
            os.remove(self.Destino+".html")
        except FileNotFoundError:
            pass
        archivo = open(self.Destino+".html", "a", encoding='utf-8')

        Cabecera = """<html><meta charset='utf-8'> 
            <style>
            table{
                font-family:Arial;
                font-size:18px;
                width:150%;
                text-align:center;
                border-collapse: collapse;
            }
            th,tr,td{
                border:2px solid gray ;
                
            }
            </style>
            <body>
            <table cellspacing="20">
            <tr>
            """
        fin_tabla = """</tr>"""
        final = """

        </table>

        </body>
            </html>"""
        archivo.write(Cabecera)
        CuerpoTabla = "<tr>"
        FinCuerpoTabla = "</tr>"

        for row in self.Cabecera:
            for item in row:
                Cabecera_Tabla = """<th>&nbsp;"""+str(item)+"""&nbsp;</th>\n"""
                archivo.write(Cabecera_Tabla+"\n")
        archivo.write(CuerpoTabla)

        for row in self.Datos:
            for items in row:

                Cuerpo_Tabla = """<td >&nbsp;"""+str(items)+"""&nbsp;</td>\n"""
                archivo.write(Cuerpo_Tabla+"\n")
            archivo.write(FinCuerpoTabla)

        archivo.write(final)
        archivo.close()

        QMessageBox.information(
            self, "OPERACIÓN REALIZADA", "Datos de la consulta exportados "+self.Opcion3.text(), QMessageBox.Ok)

        os.chdir(self.Directorio_Actual)

    def Terminar(self):
        os.chdir(self.Directorio_Actual)
        self.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    Verificar = Guardar_Opciones()
    Verificar.show()
    app.exec_()

# -*- coding: utf-8 -*-
import sys
import fdb
import re
import os
import pyodbc
import time
from PyQt5.QtWidgets import QApplication, QFileDialog, QLabel, QWidget, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon
from PyQt5 import uic


class Usuario_FireBird(QDialog):
    def __init__(self):
        QDialog.__init__(self)
        QPushButton.__init__(self)
        uic.loadUi("Usuario_FireBird.ui", self)
        self.setWindowTitle("Inicio de Sesión Firebird")

    def Cerrar(self):
        self.fileName = ""
        self.Db_User.clear()
        try:
            self.close()
        except AttributeError:
            pass

    def Cargar_Archivo(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        self.fileName, _ = QFileDialog.getOpenFileName(
            self, "QFileDialog.getOpenFileName()", "", "FireBird Files(*.fdb)")
        if self.fileName:
            self.Db_User.setText(self.fileName)

    def Enviar_Datos(self):
        self.Nombre_Usuario = self.Name_User.text()
        self.Clave_Usuario = self.Pass_User.text()
        self.dsn = self.Db_User.text()
        self.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    Verificar = Usuario_FireBird()
    Verificar.show()
    app.exec_()

import sys
from PyQt5.QtWidgets import QDialog, QLineEdit, QApplication, QLabel, QWidget, QPushButton, QColorDialog, QFontDialog
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import pyqtSlot
from PyQt5.QtGui import QFont


class Size_Letra(QDialog):
    def __init__(self):
        QDialog.__init__(self)

        self.Linea = QLabel(self)
        self.Linea.setText("Esto es una Prueba")
        # self.Texto()
        self.openFontDialog()

    def on_click(self):
        self.openFontDialog()

    def openFontDialog(self):
        Fuente, elegir = QFontDialog.getFont()

        if elegir:
            print(Fuente.pointSize())
        # for each in range(len

        else:
            QFontDefault = "Arial"

    def color_picker(self):
        Fuente = QtGui.QFontDialog.getFont()
        self.Texto()

    def Texto(self):

        self.Linea.setStyleSheet("font-size: "+Fuente.pointSize())


App = QApplication(sys.argv)
Letra = Size_Letra()
Letra.show()
sys.exit(App.exec_())

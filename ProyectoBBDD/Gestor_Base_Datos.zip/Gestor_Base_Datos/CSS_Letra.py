# -*- coding: utf-8 -*-
import os
import sys
from Gestor_Consultas import Ventana_Principal
from PyQt5.QtGui import QFont
from PyQt5 import uic
from PyQt5.QtWidgets import QColorDialog, QFontDialog, QApplication, QLabel, QWidget, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon
from Gestor_Consultas import Ventana_Principal
from PyQt5.QtGui import QColor, QIcon
from PyQt5 import QtWidgets, QtCore, QtGui


class Estilo_Letra(QDialog):
    def __init__(self):
        QDialog.__init__(self)

        uic.loadUi("Cambiar_Estilo.ui", self)
        self.setWindowTitle("Cambiar Fuente y Color")
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        # self.Tamanio_Letra_1.setSuffix("  px")
        # self.Tamanio_Letra_2.setSuffix("  px")
        # self.Tamanio_Letra_3.setSuffix("  px")
        # self.Tamanio_Letra_4.setSuffix("  px")
        try:
            for each in range(len(self.Colores)):
                if(self.Colores[each] != []):
                    pass

        except:
            self.Colores = []
    # BLOQUE 1 Y 2 ESTILO DEL ARBOL BASES DE DATOS

    def Colores_Letra1(self):
        self.Color_Elegido1 = QColorDialog.getColor().name()

    def Colores_Fondo1(self):
        self.Color_Elegido2 = QColorDialog.getColor().name()

    def Colores_Letra2(self):
        self.Color_Elegido3 = QColorDialog.getColor().name()

    def Colores_Fondo2(self):
        self.Color_Elegido4 = QColorDialog.getColor().name()

    def Colores_Letra3(self):
        self.Color_Elegido5 = QColorDialog.getColor().name()

    def Colores_Fondo3(self):
        self.Color_Elegido6 = QColorDialog.getColor().name()

    def Colores_Letra4(self):
        self.Color_Elegido7 = QColorDialog.getColor().name()

    def Colores_Fondo4(self):
        self.Color_Elegido8 = QColorDialog.getColor().name()

    def Fuente_Letra1(self):
        Fuente, elegir = QFontDialog.getFont()
        try:
            self.Fuente1 = Fuente.family()
        except AttributeError:
            pass
        try:
            self.Estilo1 = Fuente.styleName()
        except AttributeError:
            pass
        try:
            self.Size1 = int(Fuente.pointSize())
        except AttributeError:
            pass
        # print("font-family: ", Fuente.family()," Estilo: ",Fuente.styleName()," Tamaño: ",Fuente.pointSizeF())

    def Fuente_Letra2(self):
        Fuente2, elegir2 = QFontDialog.getFont()
        try:
            self.Fuente2 = Fuente2.family()
        except AttributeError:
            pass
        try:
            self.Estilo2 = Fuente2.styleName()
        except AttributeError:
            pass
        try:
            self.Size2 = int(Fuente2.pointSize())
        except AttributeError:
            pass

    def Fuente_Letra3(self):
        Fuente3, elegir3 = QFontDialog.getFont()
        try:
            self.Fuente3 = Fuente3.family()
        except AttributeError:
            pass
        try:
            self.Estilo3 = Fuente3.styleName()
        except AttributeError:
            pass
        try:
            self.Size3 = int(Fuente3.pointSize())
        except AttributeError:
            pass

    def Fuente_Letra4(self):
        Fuente4, elegir4 = QFontDialog.getFont()
        try:
            self.Fuente4 = Fuente4.family()
        except AttributeError:
            pass
        try:
            self.Estilo4 = Fuente4.styleName()
        except AttributeError:
            pass
        try:
            self.Size4 = int(Fuente4.pointSize())
        except AttributeError:
            pass

    def Verificar(self):
        try:
            self.Color_Letra1 = self.Color_Elegido1
        except AttributeError:
            pass

        try:
            self.Fuente_Elegida1 = self.Fuente1
        except AttributeError:
            pass

        try:
            self.Fuente_Estilo1 = self.Estilo1
        except AttributeError:
            pass

        try:
            self.Fuente_Size = self.Size1
        except AttributeError:
            pass

        try:
            self.Color_Fondo1 = self.Color_Elegido2
        except AttributeError:
            pass

        try:
            self.Color_Letra2 = self.Color_Elegido3
        except AttributeError:
            pass

        try:
            self.Fuente_Elegida2 = self.Fuente2
        except AttributeError:
            pass

        try:
            self.Fuente_Estilo2 = self.Estilo2
        except AttributeError:
            pass

        try:
            self.Fuente_Size2 = self.Size2
        except AttributeError:
            pass

        try:
            self.Color_Fondo2 = self.Color_Elegido4
        except AttributeError:
            pass

        try:
            self.Color_Letra3 = self.Color_Elegido5
        except AttributeError:
            pass

        try:
            self.Fuente_Elegida3 = self.Fuente3
        except AttributeError:
            pass

        try:
            self.Fuente_Estilo3 = self.Estilo3
        except AttributeError:
            pass

        try:
            self.Fuente_Size3 = self.Size3
        except AttributeError:
            pass

        try:
            self.Color_Fondo3 = self.Color_Elegido6
        except AttributeError:
            pass

        # ----------------------
        try:
            self.Color_Letra4 = self.Color_Elegido7
        except AttributeError:
            pass

        try:
            self.Fuente_Elegida4 = self.Fuente4
        except AttributeError:
            pass

        try:
            self.Fuente_Estilo4 = self.Estilo4
        except AttributeError:
            pass

        try:
            self.Fuente_Size4 = self.Size4
        except AttributeError:
            pass

        try:
            self.Color_Fondo4 = self.Color_Elegido8
        except AttributeError:
            pass
        self.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    Estilos = Estilo_Letra()
    Estilos.show()
    app.exec_()

import sys
import os
from PyQt5.QtGui import QFont, QPixmap
from PyQt5.QtWidgets import QWidget, QApplication, QFileDialog, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
from PyQt5 import QtCore
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from PIL import Image, ImageOps


class Obtein_Result(QDialog ,QPushButton):
    def __init__(self):
        
        QDialog.__init__(self)
        QPushButton.__init__(self)
        QLabel.__init__(self)
        uic.loadUi("Graficos.ui", self)
        self.setWindowTitle("Panel de Estadisticas")
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        # self.Mostrar_Grafico()
        self.Lista_Columnas.itemDoubleClicked.connect(self.Mostrar_Seleccion)
        
    def Cargar_Archivo(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        self.fileName, _ = QFileDialog.getOpenFileName(
            self, "QFileDialog.getOpenFileName()", "", "Excel/CSVFiles(*.csv *.xls *.xlsx)")
            
        if self.fileName:
            self.Nombre_Archivo.setText(self.fileName)
            self.Archivo_Elegido=self.Nombre_Archivo.text()        
        else:
            QMessageBox.warning(self,"Vacio","Tienes que cargar un archivo para ver gráficos",QMessageBox.Discard)
        
        self.Leer_Archivo()
    def Leer_Archivo(self):
        try:
            self.df=pd.read_csv(self.Archivo_Elegido)
            
        except:
            try:
                self.df=pd.read_excel(self.Archivo_Elegido)
            except:
                pass
            
    def Visualizar_Columnas(self):
        try:
            print(self.Archivo_Elegido)
            try:
                self.Lista_Columnas.clear()
                
                for each in self.df.columns:
                   self.Lista_Columnas.addItem(each)
                # print("Me has seleccionado")
                    
            except:
                self.Lista_Columnas.clear()
                
                for each in self.df.head():
                    self.Lista_Columnas.addItem(each)
        except:
            QMessageBox.warning(self,"ERROR","Necesitas cargar un archivo para poder ver las columnas",QMessageBox.Discard)
        # self.df=pd.read_excel(self.Archivo_Elegido)
        # for each in self.df.head:
                # print(each)
                
    def Mostrar_Seleccion(self):
        
        elementos = self.Lista_Columnas.selectedItems()
        # Creamos un array donde guardar los elementos seleccionados
        selected = []
        # Creamos un bucle "for" para recorrer los elementos
        for x in range(len(elementos)):
                    # Agregamos al array
            selected.append(self.Lista_Columnas.selectedItems()[x].text())
        if(self.Nombre_SeleccionX.text()==""):
            self.Nombre_SeleccionX.setText(
                str(selected).replace("['", "").replace("']", ""))
        elif(self.Nombre_SeleccionX.text()!="" and self.Nombre_SeleccionY.text()==""):
            self.Nombre_SeleccionY.setText(
                str(selected).replace("['", "").replace("']", ""))
        
        elif(self.Nombre_SeleccionX.text()!="" and self.Nombre_SeleccionY.text()!=""):
            QMessageBox.warning(self,"NO HAY ESPACIO","Ambas coordenadas están ocupadas",QMessageBox.Discard)
            
        
    def Limpiar_X(self):
        self.Nombre_SeleccionX.clear()
        
    def Limpiar_Y(self):
        self.Nombre_SeleccionY.clear()
        
        
    def Visualizar_Graficos(self):
        if(self.Histograma.isChecked()):
            self.df.plot.hist(bins=18, alpha=0.5, figsize=(12,4.5))
            plt.show()
        
        elif(self.Dispersion.isChecked()):
            try:
                if(self.Nombre_SeleccionX.text()=="" or self.Nombre_SeleccionY.text()==""):
                    QMessageBox.warning(self,"ERROR","NO se puede mostrar un gráfico sin campos que analizar",QMessageBox.Discard)
                else:
                    datos = pd.concat([self.df[self.Nombre_SeleccionX.text()], self.df[self.Nombre_SeleccionY.text()]], axis=1)
                    datos.plot.scatter(x=self.Nombre_SeleccionY.text(), y=self.Nombre_SeleccionX.text())
                    
                    plt.show()
                    
            except Exception as Error:
               QMessageBox.warning(self,"ERROR",str(Error),QMessageBox.Discard)
               
        elif(self.Barras.isChecked()):
            try:
                if(self.Nombre_SeleccionX.text()=="" or self.Nombre_SeleccionY.text()==""):
                    QMessageBox.warning(self,"ERROR","NO se puede mostrar un gráfico sin campos que analizar",QMessageBox.Discard)
                else:
                    pivot = self.df.pivot_table(index=self.Nombre_SeleccionY.text(), values=self.Nombre_SeleccionX.text(), aggfunc=np.mean)
                    pivot.plot(kind='bar')
                    plt.show()
                
                    
            except Exception as Error:
               QMessageBox.warning(self,"ERROR",str(Error),QMessageBox.Discard)
               
        elif(self.Cajas.isChecked()):
            try:
                if(self.Nombre_SeleccionX.text()=="" or self.Nombre_SeleccionY.text()==""):
                    QMessageBox.warning(self,"ERROR","NO se puede mostrar un gráfico sin campos que analizar",QMessageBox.Discard)
                else:
                    datos2 = pd.concat([self.df[self.Nombre_SeleccionX.text()], self.df[self.Nombre_SeleccionY.text()]], axis=1)
                    f, ax = plt.subplots(figsize=(12,4.5))
                    fig = sns.boxplot(x=self.Nombre_SeleccionY.text(), y=self.Nombre_SeleccionX.text(), data=datos2)
                    plt.xticks(rotation=180)
                    plt.show()
                    
            except Exception as Error:
                    QMessageBox.warning(self,"ERROR",str(Error),QMessageBox.Discard)    
        
        elif(self.Densidad.isChecked()):
            if(self.Nombre_SeleccionX.text()==""):
                    QMessageBox.warning(self,"ERROR","NO se puede mostrar un gráfico sin campos que analizar",QMessageBox.Discard)
            else:
                try:
                    sns.kdeplot(self.df[self.Nombre_SeleccionX.text()], shade=True)
                    plt.show()
                    
                except Exception as Error:
                    QMessageBox.warning(self,"ERROR",str(Error),QMessageBox.Discard) 
                          
        else:
            QMessageBox.warning(self,"ACCION INCORRECTA","Necisitas elegir una opción para ver el gráfico",QMessageBox.Discard)
            
    
   
        
        
if __name__ == '__main__':
    programa = QApplication(sys.argv)
    Dibujar = Obtein_Result()
    Dibujar.show()
    programa.exec_()

--
-- PostgreSQL database dump
--

-- Dumped from database version 10.10
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ejemplo1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ejemplo1 (
    id integer NOT NULL,
    nombre character varying(20),
    frase character varying(100)
);


ALTER TABLE public.ejemplo1 OWNER TO postgres;

--
-- Data for Name: ejemplo1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ejemplo1 (id, nombre, frase) FROM stdin;
1	Jose Mota	APAGA
2	Martes y 13	Empanadilla de Mostoles
3	Isabel Pantoja	Dientes,Dientes que es lo que joroba
\.


--
-- Name: ejemplo1 ejemplo1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ejemplo1
    ADD CONSTRAINT ejemplo1_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--


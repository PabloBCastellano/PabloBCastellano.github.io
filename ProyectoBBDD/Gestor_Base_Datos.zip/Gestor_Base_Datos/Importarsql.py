import os
usuario = 'root'
clave = 'rootroot'
salida = []
dir_actual = (os.getcwd()+(str('\\')))
print(dir_actual)
Carpeta_Seguridad = "Bases_Datos_SQL"
Encontrar = 0


def Restaurar_Bases(*args):
    os.chdir(dir_actual+str(Carpeta_Seguridad))
    Nuevo_Directorio = (os.getcwd()+str('\\'))
    print(Nuevo_Directorio)
    for each in os.listdir(Nuevo_Directorio):
        salida.append(each)

    for x in range(len(salida)):
        importar = salida[x]
        print(importar)
        # os.system('mysql  --user='+usuario+' --password='+clave+' <'+str(Nuevo_Directorio)+str(importar))
        os.system("mysql --user="+str(usuario) +
                  " --password="+str(clave)+"< "+str(importar))


for each in(os.listdir()):

    if(each == Carpeta_Seguridad):
        Encontrar = 1
        break
    else:
        Encontrar = 0

if(Encontrar == 0):
    print("La carpeta no Existe")

else:
    Restaurar_Bases()

import urllib.request
import urllib.parse
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
from PyQt5 import QtCore
import json


class Usuario_Cambiar(QDialog, QPushButton):
    def __init__(self):
        QDialog.__init__(self)
        QLabel.__init__(self)

        uic.loadUi("Actualizar_Usuario.ui", self)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, True)
        self.setWindowTitle("Modificar Usuario")

    def EndPointVerUsuario_WebServiceRest(self):
        self.Dni = self.DNI_Entrada.text()
        url = 'http://localhost:9090/segundoproyecto/api/detalleUsuario/'+self.Dni
        f = urllib.request.urlopen(url)
        Datos = f.read().decode('utf-8')
        if(Datos == ""):
            Datos = "Usuario con dni solicitado no encontrado en base de datos"
            QMessageBox.warning(
                self, "Vacio", "El usuario con DNI "+self.Dni+" no está en la base de datos", QMessageBox.Discard)
        else:
            Datos = json.loads(Datos)

            self.Nombre_Entrada.setText(str(Datos["nombre"]))
            self.Apellidos_Entrada.setText(str(Datos["apellidos"]))
            self.Edad_Entrada.setText(str(Datos["edad"]))
            self.Sexo_Entrada.setText(str(Datos["sexo"]))

    def EndPointCambiarUsuario_WebServiceRest(self):
               
        modUser = {"dni": self.DNI_Entrada.text(), "nombre": self.Nombre_Entrada.text(), "apellidos": self.Apellidos_Entrada.text(),
                   "edad": self.Edad_Entrada.text(), "sexo": self.Sexo_Entrada.text()}
        params = json.dumps(modUser).encode('utf8')
        conditionsSetURL='http://localhost:9090/segundoproyecto/api/cambiarUsuario'
        req = urllib.request.Request(conditionsSetURL, data=params,
                                     headers={'content-type': 'application/json'})
        response = urllib.request.urlopen(req)

        QMessageBox.warning(self, "Operacion Realizada ", "Usuario con DNI " +
                            response.read().decode('utf-8')+"Modificado correctamente", QMessageBox.Discard)
        self.close()


if __name__ == '__main__':
    programa = QApplication(sys.argv)
    validar = Usuario_Cambiar()
    validar.show()
    programa.exec_()

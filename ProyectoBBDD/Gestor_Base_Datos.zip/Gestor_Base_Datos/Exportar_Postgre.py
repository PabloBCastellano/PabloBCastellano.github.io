import sys

import os

import psycopg2

from PyQt5.QtWidgets import QApplication, QLabel, QWidget, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon

from PyQt5 import uic
from PyQt5 import QtCore

class Copia_Postgre(QDialog):

    def __init__(self):

        QDialog.__init__(self)

        QPushButton.__init__(self)
        uic.loadUi("Exportar_Bd.ui", self)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        self.dir_actual = (os.getcwd()+(str(os.path.sep)))
        self. Carpeta_Seguridad = "Bases_Datos_POSTGRE"
        self.setWindowTitle("Exportar Bases de Datos PostgreSQL")

    def Validar(self):
        os.chdir(self.dir_actual)
        try:
            self.cnxn.close()

        except (AttributeError, psycopg2.Error):
            pass

        try:
            self.server = 'localhost'
            self.database = ''
            self.username = self.Usuario.text()
            self.password = self.Clave.text()

            try:
                self.cnxn = psycopg2.connect(
                    user=self.username, password=self.password, database=self.database)
                self.cnxn.autocommit = True
                self.cursor = self.cnxn.cursor()

            except psycopg2.Error:

                QMessageBox.warning(self, "CONEXION FALLIDA",

                                    "Identificacion fallida", QMessageBox.Discard)

            if(self.cnxn == False):

                QMessageBox.waring(
                    self, "ERROR", "NO se ha podido conectar a la base de datos", QMessageBox.Discard)

            else:
                # self.Nueva_Base()
                self.Comprobar_Carpeta()

        except (AttributeError, psycopg2.ProgrammingError):
            pass

    def Comprobar_Carpeta(self):
        print(self.dir_actual)
        # self.Carpeta_Seguridad = "Bases_Datos_POSTGRE"
        Encontrar = 0
        for each in(os.listdir()):

            if(each == self.Carpeta_Seguridad):
                Encontrar = 1
                break
            else:
                Encontrar = 0

        if(Encontrar == 0):
            os.mkdir(self.Carpeta_Seguridad,777)
            self.Ver_Bases_Datos()
            # QMessageBox.warning(
                # self, "ERROR", "La carpeta NO Existe", QMessageBox.Discard)

        else:
            self.Ver_Bases_Datos()

    def Ver_Bases_Datos(self):
        self.Bases_Datos.clear()
        # self.cursor.execute("create database Hola_Mundo")
        Salida_Bases = "SELECT datname FROM pg_database"
        self.cursor.execute(Salida_Bases)

        self.resultado = self.cursor.fetchall()

        if(self.resultado != []):
            for each in self.resultado:
                self.campo = str(each).replace(
                    "('", "").replace("',)", "")
                print(self.campo)

                if(self.campo == "template0" or self.campo == "template1" or self.campo == "postgres"):
                    pass

                else:
                    self.Bases_Datos.addItem(self.campo)

    def Exportar_SQL(self):
        self.Seleccion = self.Bases_Datos.selectedItems()
        self.Database = []
        for each in range(len(self.Seleccion)):
            self.Database.append(
                self.Bases_Datos.selectedItems()[each].text())
        if(self.Database != []):

            print(self.dir_actual)

            Encontrar = 0
            for each in(os.listdir()):
                if(each == self.Carpeta_Seguridad):
                    Encontrar = 1
                    break

                else:
                    Encontrar = 0

            os.chdir(self.dir_actual+str(self.Carpeta_Seguridad))
            Nuevo_Directorio = (os.getcwd()+str(os.path.sep))
            print("Directorio nuevo "+Nuevo_Directorio)
            for each in range(len(self.Database)):
                guardar = self.Database[each]
                os.system("pg_dump --dbname=postgresql://"+str(self.username)+":"+str(
                    self.password)+"@127.0.0.1:5432/"+str(guardar)+">"+str(guardar)+".sql")

            QMessageBox.information(
                self, "OPERACION REALIZADA", "La copia se ha realizado con éxito", QMessageBox.Ok)

        else:
            QMessageBox.warning(self, "SELECCION NO VÁLIDA",
                                "NO has elegido ninguna base de datos para Exportar", QMessageBox.Discard)

    def Terminar(self):
        os.chdir(self.dir_actual)
        print(self.dir_actual)
        try:
            self.cnxn.close()
            self.close()
        except AttributeError:
            self.close()


if __name__ == '__main__':
    programa = QApplication(sys.argv)

    validar = Copia_Postgre()

    validar.show()

    programa.exec_()

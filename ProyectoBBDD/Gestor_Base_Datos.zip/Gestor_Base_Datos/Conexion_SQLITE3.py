# -*- coding: utf-8 -*-
import sys
import re
import os
import pyodbc
import time
from PyQt5.QtWidgets import QApplication, QFileDialog, QLabel, QWidget, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon
from PyQt5 import uic


class Activar_BD(QDialog, QPushButton):
    def __init__(self):
        QDialog.__init__(self)
        QPushButton.__init__(self)
        uic.loadUi("Usuario_SQLite.ui", self)
        self.setWindowTitle("Inicio  Sesión SQLITE")
        self.Direccion.setText(
            "Aqui aparecerá el archivo de base de datos una vez seleccionado")
        self.Nueva_Base_SQLite.setText(
            "Introduce la direccion y el nombre de la nueva base de datos")

    def Cerrar(self):
        self.close()
        self.fileName = ""
        self.Direccion.clear()

    def Cargar_Archivo(self):

        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        self.fileName, _ = QFileDialog.getOpenFileName(
            self, "QFileDialog.getOpenFileName()", "", "db Files(*.db; *.db3; *.sqlite3)")
        if self.fileName:
            self.Direccion.setText(self.fileName)
        else:
            self.Nueva_Base = self.Nueva_Base_SQLite.text()

    def Enviar_BaseDatos(self):
        try:

            QMessageBox.information(
                self, "CORRECTO", "Se ha seleccionado la base de datos", QMessageBox.Ok)
            self.close()
        except AttributeError:
            QMessageBox.warning(
                self, "Vacio", "NO has seleccionado la base de datos", QMessageBox.Discard)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    Buscar = Activar_BD()
    Buscar.show()
    app.exec_()

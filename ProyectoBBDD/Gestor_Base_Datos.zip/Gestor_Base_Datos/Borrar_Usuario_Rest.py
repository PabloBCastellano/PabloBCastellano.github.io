import urllib.request
import urllib.parse
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
from PyQt5 import QtCore
import json


class APIWEB(QDialog, QPushButton):
    def __init__(self):
        QDialog.__init__(self)
        QLabel.__init__(self)

        uic.loadUi("Borrar_UsuarioRest.ui", self)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, True)
        self.setWindowTitle("Borrar Usuario")

    def EndPointVerUsuario_WebServiceRest(self):
        self.Dni = self.DNI_Entrada.text()
        try:
            url = 'http://localhost:9090/segundoproyecto/api/detalleUsuario/'+self.Dni
            f = urllib.request.urlopen(url)
            Datos = f.read().decode('utf-8')

            if(Datos == ""):
                Datos = "Usuario con dni solicitado no encontrado en base de datos"
                QMessageBox.warning(
                    self, "Vacio", "El usuario con DNI "+self.Dni+" no está en la base de datos", QMessageBox.Discard)
            else:
                Datos = json.loads(Datos)

                self.Nombre_Entrada.setText(str(Datos["nombre"]))
                self.Apellidos_Entrada.setText(str(Datos["apellidos"]))
                self.Edad_Entrada.setText(str(Datos["edad"]))
                self.Sexo_Entrada.setText(str(Datos["sexo"]))
        except:
            QMessageBox.warning(
                self, "ERROR", "NO SE HA PODIDO REALIZAR LA CONEXION CON EL WEB SERVICE.VERIFIQUE LA CONEXIÓN", QMessageBox.Discard)

    def EndPointBorrarUsuario_WebServiceRest(self):
        self.Dni = self.DNI_Entrada.text()
        try:
            url = 'http://localhost:9090/segundoproyecto/api/eliminarusuario/'+self.Dni
            f = urllib.request.urlopen(url)

            # print(f.read().decode('utf-8'))
            QMessageBox.warning(self, "Borrado ", "Usuario con DNI " +
                                f.read().decode('utf-8')+" borrado correctamente", QMessageBox.Discard)
            self.close()
        except:
           QMessageBox.warning(
                self, "ERROR", "NO SE HA PODIDO REALIZAR LA CONEXION CON EL WEB SERVICE.VERIFIQUE LA CONEXIÓN", QMessageBox.Discard)


if __name__ == '__main__':
    programa = QApplication(sys.argv)
    validar = APIWEB()
    validar.show()
    programa.exec_()

--
-- PostgreSQL database dump
--

-- Dumped from database version 11.6
-- Dumped by pg_dump version 11.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ejemplo1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ejemplo1 (
    id integer NOT NULL,
    nombre character varying(20) NOT NULL,
    cancion character varying(50)
);


ALTER TABLE public.ejemplo1 OWNER TO postgres;

--
-- Name: ejemplo2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ejemplo2 (
    id integer NOT NULL,
    color character varying(10)
);


ALTER TABLE public.ejemplo2 OWNER TO postgres;

--
-- Name: ejemplo3; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ejemplo3 (
    id integer NOT NULL,
    titulo_libro character varying(50) NOT NULL,
    autor character varying(50) NOT NULL,
    num_paginas integer
);


ALTER TABLE public.ejemplo3 OWNER TO postgres;

--
-- Data for Name: ejemplo1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ejemplo1 (id, nombre, cancion) FROM stdin;
1	Isabel Pantoja	Se me enamora el Alma
2	Marifé de Triana	Torre de Arena
3	Juanita Reina	Madrina
20	Purpura	\N
4	Gracia Montes	Maruja Limón
5	Lola Flores	A tu vera
\.


--
-- Data for Name: ejemplo2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ejemplo2 (id, color) FROM stdin;
1	Amarillo
2	Rojo
3	Azul
\.


--
-- Data for Name: ejemplo3; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ejemplo3 (id, titulo_libro, autor, num_paginas) FROM stdin;
\.


--
-- Name: ejemplo1 ejemplo1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ejemplo1
    ADD CONSTRAINT ejemplo1_pkey PRIMARY KEY (id);


--
-- Name: ejemplo2 ejemplo2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ejemplo2
    ADD CONSTRAINT ejemplo2_pkey PRIMARY KEY (id);


--
-- Name: ejemplo3 ejemplo3_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ejemplo3
    ADD CONSTRAINT ejemplo3_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--


-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: seguros
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `seguros`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `seguros` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `seguros`;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `DNI_Cliente` varchar(15) NOT NULL,
  `Nombre_Apellidos` varchar(100) NOT NULL,
  `Calle` varchar(50) NOT NULL,
  `Ciudad` varchar(20) NOT NULL,
  `Tipo_Cliente` enum('BRONCE','PLATA','ORO') DEFAULT NULL,
  PRIMARY KEY (`DNI_Cliente`),
  UNIQUE KEY `DNI_Cliente` (`DNI_Cliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES ('00001','Nombre Completo 1','Calle 1','Ciudad 1','PLATA'),('00002','Nombre Completo 2','Calle 2','Ciudad 2','BRONCE'),('00003','Nombre Completo 3','Calle 3','Ciudad 3','PLATA'),('00004','Nombre Completo 4','Calle 4','Ciudad 4','PLATA'),('00006','Nombre Completo 6','Calle 6','Ciudad 6','BRONCE'),('0003','Nombre Completo3','Calle 3','Ciudad 3',NULL),('0010','Nombre Completo3','Calle 3','Ciudad 3',NULL);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `clientes_oro`
--

DROP TABLE IF EXISTS `clientes_oro`;
/*!50001 DROP VIEW IF EXISTS `clientes_oro`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `clientes_oro` AS SELECT 
 1 AS `Nombre_Apellidos`,
 1 AS `Modelo_Vehiculo`,
 1 AS `Fecha_Alta`,
 1 AS `Num_Poliza`,
 1 AS `Tipo_Cliente`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `coches_asegurados`
--

DROP TABLE IF EXISTS `coches_asegurados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coches_asegurados` (
  `Num_Poliza` int(11) NOT NULL AUTO_INCREMENT,
  `Num_Matricula` int(10) NOT NULL,
  `DNI_Cliente` varchar(15) NOT NULL,
  `Fecha_Alta` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Num_Poliza`),
  KEY `Num_Matricula` (`Num_Matricula`),
  KEY `DNI_Cliente` (`DNI_Cliente`),
  CONSTRAINT `coches_asegurados_ibfk_1` FOREIGN KEY (`Num_Matricula`) REFERENCES `vehiculos` (`Num_Matricula`),
  CONSTRAINT `coches_asegurados_ibfk_2` FOREIGN KEY (`DNI_Cliente`) REFERENCES `clientes` (`DNI_Cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coches_asegurados`
--

LOCK TABLES `coches_asegurados` WRITE;
/*!40000 ALTER TABLE `coches_asegurados` DISABLE KEYS */;
INSERT INTO `coches_asegurados` VALUES (1,1,'00001','2019-05-29 00:00:00'),(2,2,'00002','2019-05-29 00:00:00'),(3,3,'00003','2019-05-29 00:00:00'),(4,4,'00004','2019-05-29 00:00:00'),(5,4,'00004','2019-05-29 00:00:00'),(10,6,'00006','2019-06-03 14:14:19'),(12,6,'00006','2019-06-03 14:16:23'),(13,6,'00006','2019-06-03 14:16:30'),(14,6,'00006','2019-06-03 14:16:31'),(15,6,'00006','2019-06-03 14:16:31'),(16,6,'00006','2019-06-03 14:16:31'),(17,6,'00006','2019-06-03 14:16:32'),(18,6,'00006','2019-06-03 14:18:49'),(19,6,'00006','2019-06-03 14:19:57'),(20,7,'00006','2019-06-03 14:32:33'),(23,10,'00006','2019-06-03 14:51:10'),(24,35,'00006','2019-06-03 17:09:29'),(25,11,'00001','2019-06-03 17:16:42'),(26,12,'00001','2019-06-03 17:17:24'),(27,13,'00001','2019-06-03 17:17:35');
/*!40000 ALTER TABLE `coches_asegurados` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `Actualizar_Cliente` AFTER INSERT ON `coches_asegurados` FOR EACH ROW begin
	declare Num_Polizas INT(11);
	set Num_Polizas=(select count(*) from coches_asegurados where DNI_Cliente=new.DNI_Cliente);
	if(Num_Polizas<=3)then
		update clientes set Tipo_Cliente='Bronce' where `DNI_Cliente`=new.DNI_Cliente;
	
	elseif(Num_Polizas>3 and Num_Polizas<6)then
		update clientes set `Tipo_Cliente`='Plata' where `DNI_Cliente`=new.DNI_Cliente;
	else 
		update clientes set `Tipo_Cliente`='Oro'where DNI_Cliente=new.DNI_Cliente;
	end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `pasajeros`
--

DROP TABLE IF EXISTS `pasajeros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pasajeros` (
  `PassangerId` int(11) NOT NULL,
  `Survived` varchar(12) DEFAULT NULL,
  `PClass` int(11) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Sex` varchar(20) DEFAULT NULL,
  `Age` float DEFAULT NULL,
  `SibSp` int(11) DEFAULT NULL,
  `Parch` int(11) DEFAULT NULL,
  `Ticket` varchar(20) DEFAULT NULL,
  `Fare` float DEFAULT NULL,
  `Cabin` varchar(20) DEFAULT NULL,
  `Embarked` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`PassangerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pasajeros`
--

LOCK TABLES `pasajeros` WRITE;
/*!40000 ALTER TABLE `pasajeros` DISABLE KEYS */;
/*!40000 ALTER TABLE `pasajeros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehiculos`
--

DROP TABLE IF EXISTS `vehiculos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehiculos` (
  `Num_Matricula` int(10) NOT NULL,
  `Fecha_Matriculacion` datetime NOT NULL,
  `Modelo_Vehiculo` varchar(50) NOT NULL,
  `CW_Potencia` int(4) NOT NULL,
  `Color_Vehiculo` varchar(20) NOT NULL,
  `Marca_Vehiculo` varchar(50) NOT NULL,
  PRIMARY KEY (`Num_Matricula`),
  UNIQUE KEY `Num_Matricula` (`Num_Matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehiculos`
--

LOCK TABLES `vehiculos` WRITE;
/*!40000 ALTER TABLE `vehiculos` DISABLE KEYS */;
INSERT INTO `vehiculos` VALUES (1,'2000-02-01 00:00:00','Modelo1',130,'Rojo','Marca1'),(2,'2002-02-01 00:00:00','Modelo2',140,'Rojo','Marca2'),(3,'2003-02-01 00:00:00','Modelo3',150,'Rojo','Marca3'),(4,'2004-02-01 00:00:00','Modelo4',125,'Rojo','Marca1'),(6,'2004-02-02 00:00:00','Modelo1',130,'Rojo','Marca1'),(7,'1975-12-25 00:00:00','Modelo 5',120,'Rojo','Marca 5'),(8,'1975-12-25 00:00:00','Modelo 5',120,'Rojo','Marca 5'),(9,'1975-12-25 00:00:00','Modelo 5',120,'Rojo','Marca 5'),(10,'1975-12-25 00:00:00','Modelo 5',120,'Rojo','Marca 5'),(11,'1945-12-03 00:00:00','Modelo1',135,'Rojo','Marca1'),(12,'1945-12-03 00:00:00','Modelo1',135,'Rojo','Marca1'),(13,'1945-12-03 00:00:00','Modelo1',135,'Rojo','Marca1'),(35,'1975-12-25 00:00:00','Modelo 5',120,'Rojo','Marca 5');
/*!40000 ALTER TABLE `vehiculos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Current Database: `seguros`
--

USE `seguros`;

--
-- Final view structure for view `clientes_oro`
--

/*!50001 DROP VIEW IF EXISTS `clientes_oro`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `clientes_oro` AS select `clientes`.`Nombre_Apellidos` AS `Nombre_Apellidos`,`vehiculos`.`Modelo_Vehiculo` AS `Modelo_Vehiculo`,`coches_asegurados`.`Fecha_Alta` AS `Fecha_Alta`,`coches_asegurados`.`Num_Poliza` AS `Num_Poliza`,`clientes`.`Tipo_Cliente` AS `Tipo_Cliente` from ((`clientes` join `coches_asegurados`) join `vehiculos`) where ((`clientes`.`DNI_Cliente` = `coches_asegurados`.`DNI_Cliente`) and (`vehiculos`.`Num_Matricula` = `coches_asegurados`.`Num_Matricula`) and (`clientes`.`Tipo_Cliente` = 'Oro')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-17 11:55:49

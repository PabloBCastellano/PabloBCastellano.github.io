function confirmarOpcionBorrar(context,dni_Usuario){

    var res=confirm("¿Estas seguro de querer borrar el usuario con DNI "+dni_Usuario+"?");
    if(res){
        $.ajax({
            method : "GET",
            url : context+"/api/eliminarusuario/"+dni_Usuario,
            async: false,
            timeout: 30000,
            success: function(result){
                var dni_res=result;
                alert("Usuario con DNI "+dni_res+" borrado correctamente");
                window.location.href=context+"/UsuariosRegistrados";
            },
            error: function (jqXHR, exception) {
                var msg = '';

                msg = 'Error capturado\n' + jqXHR.responseText;

                $.MessageBox("Error de servidor: "+msg);

            }
        });

    }


}
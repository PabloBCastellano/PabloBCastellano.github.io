package org.example.controller;

import org.example.model.UsuarioModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@RestController
public class RestMainController {

    @Autowired
    private DataSource dataSource;

    @GetMapping("/api/eliminarusuario/{dni}")
    public String eliminarUsuario(HttpServletRequest request, Model model, @PathVariable String dni) throws Exception {
        //PathVariable para un parametro como variable de la url
        //Conexion a bbdd
        Connection connection = dataSource.getConnection();
        //metemos codigo acceso a bbdd en controller porque estamos en una prueba rapida
        String updateSql = "delete from control_datos_usuario where DNI_Usuario=?";
        PreparedStatement preparedStatement = connection.prepareStatement(updateSql);
        preparedStatement.setString(1, dni);
        preparedStatement.executeUpdate();
        preparedStatement.close();
        connection.close();
        return dni;
    }

    @PostMapping("/api/crearusuario")
    public String verificarAlta(HttpServletRequest request, Model model, @RequestBody UsuarioModel usuarioModel) throws Exception {


        //Conexion a bbdd
        Connection connection = dataSource.getConnection();

        String insertSql = "insert into control_datos_usuario values (?,?,?,?,?)";

        PreparedStatement preparedStatement = connection.prepareStatement(insertSql);
        preparedStatement.setString(1, usuarioModel.getDni());
        preparedStatement.setString(2, usuarioModel.getNombre());
        preparedStatement.setString(3, usuarioModel.getApellidos());
        preparedStatement.setInt(4, usuarioModel.getEdad());
        preparedStatement.setString(5, usuarioModel.getSexo());

        preparedStatement.executeUpdate();

        preparedStatement.close();
        connection.close();


        return usuarioModel.getDni();


    }

    @GetMapping("/api/detalleUsuario/{dni}")//Indica la URL donde se carga
    public ResponseEntity<?> showDetalles(HttpServletRequest request, Model model, @PathVariable String dni) {
        UsuarioModel usuarioModel = null;
        try {
            Connection connection = dataSource.getConnection();
            String consulta = "select * from control_datos_usuario where DNI_Usuario=?";
            PreparedStatement preparedStatement = connection.prepareStatement(consulta);
            preparedStatement.setString(1, dni);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                usuarioModel = new UsuarioModel();
                usuarioModel.setDni(rs.getString(1));
                //usuarioModel.setDni(rs.getString("DNI_Usuario"));
                usuarioModel.setNombre(rs.getString(2));
                usuarioModel.setApellidos(rs.getString(3));
                usuarioModel.setEdad(rs.getInt(4));
                usuarioModel.setSexo(rs.getString(5));
            }


            preparedStatement.close();
            connection.close();


        } catch (Exception ex) {
            ex.printStackTrace();
        }

        ResponseEntity<?> responseEntity = new ResponseEntity<UsuarioModel>(usuarioModel, HttpStatus.OK);
        return responseEntity;
    }

    @PostMapping("/api/cambiarUsuario")
    public String modificarUsuario(HttpServletRequest request, Model model,@RequestBody UsuarioModel usuarioModel) throws Exception{
        //Conexion a bbdd
        Connection connection=dataSource.getConnection();

        String updateSql="update control_datos_usuario set Nombre_Usuario=?,Apellidos_Usuario=?," +
                "Edad=?,Sexo=? where DNI_Usuario=?";

        PreparedStatement preparedStatement=connection.prepareStatement(updateSql);

        preparedStatement.setString(1,usuarioModel.getNombre());
        preparedStatement.setString(2,usuarioModel.getApellidos());
        preparedStatement.setInt(3,usuarioModel.getEdad());
        preparedStatement.setString(4,usuarioModel.getSexo());
        preparedStatement.setString(5,usuarioModel.getDni());
        preparedStatement.executeUpdate();

        preparedStatement.close();
        connection.close();


        return usuarioModel.getDni();

    }

    @GetMapping("/api/UsuariosRegistrados")//Indica la URL donde se carga
    public ResponseEntity<?> showUsuariosRegistrados(HttpServletRequest request, Model model){
        List<UsuarioModel> lista=new ArrayList<UsuarioModel>();
        UsuarioModel usuarioModel=null;
        try {
            Connection connection=dataSource.getConnection();
            String consulta="select * from control_datos_usuario order by DNI_Usuario asc";
            PreparedStatement preparedStatement=connection.prepareStatement(consulta);
            ResultSet rs=preparedStatement.executeQuery();

            while(rs.next()){
                usuarioModel=new UsuarioModel();
                usuarioModel.setDni(rs.getString(1));
                //usuarioModel.setDni(rs.getString("DNI_Usuario"));
                usuarioModel.setNombre(rs.getString(2));
                usuarioModel.setApellidos(rs.getString(3));
                usuarioModel.setEdad(rs.getInt(4));
                usuarioModel.setSexo(rs.getString(5));


                lista.add(usuarioModel);

            }
            preparedStatement.close();
            connection.close();

        }catch (Exception ex){
            ex.printStackTrace();
        }

        ResponseEntity<?> responseEntity=new ResponseEntity<List<UsuarioModel>>(lista,HttpStatus.OK);


        return responseEntity ;
    }

}

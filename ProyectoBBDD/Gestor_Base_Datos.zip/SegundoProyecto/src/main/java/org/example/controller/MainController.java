package org.example.controller;

import org.example.model.UsuarioModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;


import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Controller
public class MainController {

    @Autowired
    private DataSource dataSource;

    @GetMapping("/formulario")//Indica la URL donde se carga
    public String showForm(HttpServletRequest request, Model model){
        return "/WEB-INF/views/formulario.jsp";
    }
    @PostMapping("/Verificar_Alta")
    public String verificarAlta(HttpServletRequest request, Model model) throws Exception{
        String dni=request.getParameter("DNI_user");
        String nombre=request.getParameter("name_user");
        String apellidos=request.getParameter("App_user");
        Integer edad= Integer.valueOf(request.getParameter("edad_user"));
        String sexo=request.getParameter("Gen_user");

        //Conexion a bbdd
        Connection connection=dataSource.getConnection();

        String insertSql="insert into control_datos_usuario values (?,?,?,?,?)";

        PreparedStatement preparedStatement=connection.prepareStatement(insertSql);
        preparedStatement.setString(1,dni);
        preparedStatement.setString(2,nombre);
        preparedStatement.setString(3,apellidos);
        preparedStatement.setInt(4,edad);
        preparedStatement.setString(5,sexo);

        preparedStatement.executeUpdate();

        preparedStatement.close();
        connection.close();



        return showUsuariosRegistrados(request,model);

        //return "/WEB-INF/views/formulario.jsp";
    }

    @GetMapping("/UsuariosRegistrados")//Indica la URL donde se carga
    public String showUsuariosRegistrados(HttpServletRequest request, Model model){
        try {
            Connection connection=dataSource.getConnection();
            String consulta="select * from control_datos_usuario order by DNI_Usuario asc";
            PreparedStatement preparedStatement=connection.prepareStatement(consulta);
            ResultSet rs=preparedStatement.executeQuery();
            List<UsuarioModel> lista=new ArrayList<UsuarioModel>();
            while(rs.next()){
                UsuarioModel usuarioModel=new UsuarioModel();
                usuarioModel.setDni(rs.getString(1));
                //usuarioModel.setDni(rs.getString("DNI_Usuario"));
                usuarioModel.setNombre(rs.getString(2));
                usuarioModel.setApellidos(rs.getString(3));
                usuarioModel.setEdad(rs.getInt(4));
                usuarioModel.setSexo(rs.getString(5));


               lista.add(usuarioModel);

            }
            preparedStatement.close();
            connection.close();
            model.addAttribute("controlRegistro",lista);

        }catch (Exception ex){
            ex.printStackTrace();
        }


        return "/WEB-INF/views/listado.jsp";
    }

    @GetMapping("/DetalleUsuario")//Indica la URL donde se carga
    public String showDetalles(HttpServletRequest request, Model model){
        try {
            Connection connection=dataSource.getConnection();
            String consulta="select * from control_datos_usuario where DNI_Usuario=?";
            PreparedStatement preparedStatement=connection.prepareStatement(consulta);
            preparedStatement.setString(1,request.getParameter("dni_entrada"));
            ResultSet rs=preparedStatement.executeQuery();
            UsuarioModel usuarioModel=new UsuarioModel();
            if(rs.next()){

                usuarioModel.setDni(rs.getString(1));
                //usuarioModel.setDni(rs.getString("DNI_Usuario"));
                usuarioModel.setNombre(rs.getString(2));
                usuarioModel.setApellidos(rs.getString(3));
                usuarioModel.setEdad(rs.getInt(4));
                usuarioModel.setSexo(rs.getString(5));
            }

            preparedStatement.close();
            connection.close();
            model.addAttribute("usuarioDni",usuarioModel);

        }catch (Exception ex){
            ex.printStackTrace();
        }


        return "/WEB-INF/views/detalle.jsp";
    }
    @GetMapping("/UsuarioModificar")//Indica la URL donde se carga
    public String showcambiarUsuario(HttpServletRequest request, Model model){
        try {
            Connection connection=dataSource.getConnection();
            String consulta="select * from control_datos_usuario where DNI_Usuario=?";
            PreparedStatement preparedStatement=connection.prepareStatement(consulta);
            preparedStatement.setString(1,request.getParameter("dni_entrada"));
            ResultSet rs=preparedStatement.executeQuery();
            UsuarioModel usuarioModel=new UsuarioModel();
            if(rs.next()){

                usuarioModel.setDni(rs.getString(1));
                //usuarioModel.setDni(rs.getString("DNI_Usuario"));
                usuarioModel.setNombre(rs.getString(2));
                usuarioModel.setApellidos(rs.getString(3));
                usuarioModel.setEdad(rs.getInt(4));
                usuarioModel.setSexo(rs.getString(5));
            }

            preparedStatement.close();
            connection.close();
            model.addAttribute("usuarioDni",usuarioModel);

        }catch (Exception ex){
            ex.printStackTrace();
        }


        return "/WEB-INF/views/formulariocambiar.jsp";
    }

    @PostMapping("/Modificar_Usuario")
    public String modificarUsuario(HttpServletRequest request, Model model) throws Exception{
        String dni=request.getParameter("DNI_user");
        String nombre=request.getParameter("name_user");
        String apellidos=request.getParameter("App_user");
        Integer edad= Integer.valueOf(request.getParameter("edad_user"));
        String sexo=request.getParameter("Gen_user");

        //Conexion a bbdd
        Connection connection=dataSource.getConnection();

        String updateSql="update control_datos_usuario set Nombre_Usuario=?,Apellidos_Usuario=?," +
                "Edad=?,Sexo=? where DNI_Usuario=?";

        PreparedStatement preparedStatement=connection.prepareStatement(updateSql);

        preparedStatement.setString(1,nombre);
        preparedStatement.setString(2,apellidos);
        preparedStatement.setInt(3,edad);
        preparedStatement.setString(4,sexo);
        preparedStatement.setString(5,dni);
        preparedStatement.executeUpdate();
    
        //HACEMOS TRANSACCIONAL EL EJEMPLO QUE ESTAMOS VIENDO
        /*connection.setAutoCommit(false);

        String updateSql1="update control_datos_usuario set Nombre_Usuario=?,Apellidos_Usuario=? where DNI_Usuario=?";

        PreparedStatement preparedStatement=connection.prepareStatement(updateSql1);

        preparedStatement.setString(1,nombre);
        preparedStatement.setString(2,apellidos);
        preparedStatement.setString(3,dni);
        preparedStatement.executeUpdate();

        //GAZAPO para forzar una excepcion por nullpointerexception
        //UsuarioModel modelForzarExcep=null;
        //modelForzarExcep.getDni();

        String updateSql2="update control_datos_usuario set Edad=?,Sexo=? where DNI_Usuario=?";

        preparedStatement=connection.prepareStatement(updateSql2);

        preparedStatement.setInt(1,edad);
        preparedStatement.setString(2,sexo);
        preparedStatement.setString(3,dni);
        preparedStatement.executeUpdate();

        connection.commit();*/






        preparedStatement.close();
        connection.close();



        return showUsuariosRegistrados(request,model);

    }


    @GetMapping("/Eliminar_Usuario")
    public String eliminarUsuario(HttpServletRequest request, Model model) throws Exception{
        String dni=request.getParameter("dni_entrada");


        //Conexion a bbdd
        Connection connection=dataSource.getConnection();

        String updateSql="delete from control_datos_usuario where DNI_Usuario=?";

        PreparedStatement preparedStatement=connection.prepareStatement(updateSql);
        preparedStatement.setString(1,dni);
        preparedStatement.executeUpdate();
        preparedStatement.close();
        connection.close();



        return showUsuariosRegistrados(request,model);

    }


}

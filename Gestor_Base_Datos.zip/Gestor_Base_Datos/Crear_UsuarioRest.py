import urllib.request
import urllib.parse
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
from PyQt5 import QtCore
import json


class Nuevo_Usuario(QDialog, QPushButton):
    def __init__(self):
        QDialog.__init__(self)
        QLabel.__init__(self)

        uic.loadUi("Crear_UsuarioRest.ui", self)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, True)
        self.setWindowTitle("Crear Usuario")

    def EndPointCrearUsuario_WebServiceRest(self):
        self.Dni = self.Dni_Entrada.text()
        self.Nombre = self.Nombre_Entrada.text()
        self.Apellidos = self.Apellidos_Entrada.text()
        self.Edad = int(self.Edad_Entrada.text())
        self.Sexo = self.Sexo_Entrada.text()

        newUser = {"dni": self.Dni, "nombre": self.Nombre, "apellidos": self.Apellidos,
                   "edad": self.Edad, "sexo": self.Sexo}
        params = json.dumps(newUser).encode('utf8')
        conditionsSetURL='http://localhost:9090/segundoproyecto/api/crearusuario'
        req = urllib.request.Request(conditionsSetURL, data=params,
                                     headers={'content-type': 'application/json'})
        response = urllib.request.urlopen(req)

        QMessageBox.warning(self, "Operacion Realizada ", "Usuario con DNI " +
                            response.read().decode('utf-8')+" dado de alta", QMessageBox.Discard)
        self.close()


if __name__ == '__main__':
    programa = QApplication(sys.argv)
    validar = APIWEB()
    validar.show()
    programa.exec_()

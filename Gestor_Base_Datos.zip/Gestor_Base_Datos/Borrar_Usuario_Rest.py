import urllib.request
import urllib.parse
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
from PyQt5 import QtCore


class APIWEB(QDialog, QPushButton):
    def __init__(self):
        QDialog.__init__(self)
        QLabel.__init__(self)

        uic.loadUi("Borrar_UsuarioRest.ui", self)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint,True)
        self.setWindowTitle("Borrar Usuario")

    def EndPointBorrarUsuario_WebServiceRest(self):
        self.Dni = self.Dni_Entrada.text()
        url = 'http://localhost:9090/segundoproyecto/api/eliminarusuario/'+self.Dni
        f = urllib.request.urlopen(url)
        
        # print(f.read().decode('utf-8'))
        QMessageBox.warning(self, "Borrado ", "Usuario con DNI " +
                           f.read().decode('utf-8')+" borrado correctamente", QMessageBox.Discard)
        self.close()
if __name__ == '__main__':
    programa = QApplication(sys.argv)
    validar = APIWEB()
    validar.show()
    programa.exec_()
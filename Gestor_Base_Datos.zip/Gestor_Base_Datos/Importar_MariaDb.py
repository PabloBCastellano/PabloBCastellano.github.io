import sys

import os

# import pyodbc
import pyodbc

from PyQt5.QtWidgets import QApplication, QLabel, QWidget, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon

from PyQt5 import uic
from PyQt5 import QtCore

class Retornar_MariaDb(QDialog):

    def __init__(self):

        QDialog.__init__(self)

        QPushButton.__init__(self)
        uic.loadUi("Importar_Bd.ui", self)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        self.dir_actual = (os.getcwd()+(str(os.path.sep)))
        self.Carpeta_Seguridad = "Bases_Datos_MariaDB"
        self.setWindowTitle("Importar Bases de Datos MariaDB")

    def Validar(self):
        os.chdir(self.dir_actual)

        try:
            self.cnxn.close()

        except Exception as Error:
            pass

        try:
            self.server = 'localhost'
            self.database = ''
            self.username = self.Usuario.text()
            self.password = self.Clave.text()

            try:
                self.cnxn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 ANSI Driver};SERVER='+self.server +
                ';DATABASE='+self.database+';UID='+self.username+';PWD=' + self.password,port=3310)
                self.cursor = self.cnxn.cursor()

            except Exception as Error:

                QMessageBox.warning(self, "CONEXION FALLIDA",

                                    "Identificacion fallida", QMessageBox.Discard)

            if(self.cnxn == False):

                QMessageBox.waring(
                    self, "ERROR", "NO se ha podido conectar a la base de datos", QMessageBox.Discard)

            else:

                self.Comprobar_Carpeta()

        except Exception as Error:
            pass

    def Comprobar_Carpeta(self):
        print(self.dir_actual)

        Encontrar = 0
        for each in(os.listdir()):

            if(each == self.Carpeta_Seguridad):
                Encontrar = 1
                break
            else:
                Encontrar = 0

        if(Encontrar == 0):
            QMessageBox.warning(
                self, "ERROR", "La carpeta NO Existe", QMessageBox.Discard)

        else:
            self.Ver_Archivos()

    def Ver_Archivos(self):
        os.chdir(self.dir_actual+str(self.Carpeta_Seguridad))
        self.Nuevo_Directorio = (os.getcwd()+str(os.path.sep))
        print(self.Nuevo_Directorio)
        self.Bases_Datos.clear()
        for each in(os.listdir(self.Nuevo_Directorio)):
            self.Bases_Datos.addItem(each)

    def Importar_SQL(self):
        self.Seleccion = self.Bases_Datos.selectedItems()
        self.Database = []
        for each in range(len(self.Seleccion)):
            self.Database.append(
                self.Bases_Datos.selectedItems()[each].text())
        if(self.Database != []):
            for each in range(len(self.Database)):
                guardar = self.Database[each]
                print(guardar)
                os.system("mariadb --user="+str(self.username)+" --password=" +
                          str(self.password)+" <"+str(guardar))
            QMessageBox.information(
                self, "OPERACION REALIZADA", "La importacion se ha realizado  con éxito", QMessageBox.Ok)

        else:
            QMessageBox.warning(self, "SELECCION NO VÁLIDA",
                                "NO has elegido ninguna base de datos para Importar", QMessageBox.Discard)

    def Terminar(self):
        os.chdir(self.dir_actual)
        print(self.dir_actual)
        try:
            self.cnxn.close()
            self.cursor.close()
        except Exception as Error:
            pass
        self.close()


if __name__ == '__main__':

    programa = QApplication(sys.argv)

    validar = Retornar_SQL()

    validar.show()

    programa.exec_()

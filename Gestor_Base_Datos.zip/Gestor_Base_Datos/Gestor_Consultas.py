# -*- coding: utf-8 -*-
import sys
import re
import os
import pyodbc
# import pymysql as sql
import fdb
import sqlite3
import psycopg2
import ctypes
from Gestor_Ayudas import Ventana_Ayuda
from Importar_Mysql import Retornar_SQL
from Importar_MariaDb import Retornar_MariaDb
from Importar_SQL2017 import Restaurar_SQL2017
from Importar_Postgre import Restaurar_Postgre
from Exportar_Mysql import Copia_SQL
from Exportar_MariaDb import Copia_MariaDB
from Exportar_SQL2017 import Copia_SQL2017
from Exportar_Postgre import Copia_Postgre
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
from PyQt5 import QtCore
from Conexion_SQL import Ventana_Conexion
from Usuario_MariaDb import Conexion_Maridb
from Conexion_SQLITE3 import Activar_BD
from Conexion_FireBird import Usuario_FireBird
from Usuario_Postgre import Inicio_Postgre
from Borrar_Usuario_Rest import *
from Escribir_CSV import Guardar_Opciones
from Generar_Dibujo import Obtein_Result
from Crear_UsuarioRest import *
from Detalles_Usuario_Rest import *
from Generar_Tendencias import Tendencia_Global
from Palabra_Buscada import Palabra_Aparece
workingDir = os.getcwd()

sys.path.append('.')


class Ventana_Principal(QMainWindow, QPushButton):
    def __init__(self):
        QMainWindow.__init__(self)
        QLabel.__init__(self)

        uic.loadUi("Gestor_Consultas.ui", self)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint, False)
        self.setWindowTitle("Gestor de Bases de Datos")
        
        try:
            self.resolucion = ctypes.windll.user32
            self.Ancho = self.resolucion.GetSystemMetrics(0)
            self.Alto = self.resolucion.GetSystemMetrics(1)

            if(self.Ancho == 1366 and self.Alto == 768):
                pass
            else:
                                            # print("Pantalla demasiado grande")
                self.resize(1500, 750)
                self.setMaximumSize(1500, 750)

        except Exception as Error:
            self.setMaximumSize(1500, 750)

        #print(self.Ancho, self.Alto)
        self.BasesDatos_Info.itemDoubleClicked.connect(self.Ver_Tablas)
        self.Salidas.setTabText(1, "Resultados de la Consulta")
        self.Salidas.setTabText(0, "Numero Filas Devueltas")

    def Salir(self):
        self.close()

    def Sesion_SQL(self):

        self.Consulta_Entrada.clear()
        self.Consulta_Salida.clear()
        self.BasesDatos_Info.clear()
        self.Tablas_Info.clear()
        self.Numero_Filas.clear()
        # self.Salidas.setTabText(1, self.Numero_Filas.setText(""))
        # self.Salidas.setTabText(1, "Resultados de la Consulta")
        # self.Salidas.setTabText(0, "Numero Filas Devueltas")
        try:
            self.cnxn.close()

        except Exception as Error:
            pass
        Iniciar = Ventana_Conexion()
        Iniciar.exec_()
        try:
            self.server = 'localhost'
            self.database = ''
            self.username = Iniciar.username
            self.password = Iniciar.password
            try:
                # self.cnxn = sql.connect(host=self.server,
                                        # database=self.database, user=self.username, password=self.password, port=3306)
                self.cnxn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 ANSI Driver};SERVER='+self.server +
                                           ';DATABASE='+self.database+';UID='+self.username+';PWD=' + self.password, port=3306)
                self.cursor = self.cnxn.cursor()
            except Exception as Error:
                QMessageBox.warning(self, "CONEXION FALLIDA",
                                    "Identificacion fallida", QMessageBox.Discard)
                self.Sesion_SQL()
            if(self.cnxn == False):
                QMessageBox.waring(
                    self, "ERROR", "NO se ha podido conectar a la base de datos", QMessageBox.Discard)
            else:
                self.BasesDatos_Info.show()
                self.Mostrar_Bases_Datos()
                self.actionUpdateBaseDatos.setEnabled(True)
                self.actionUpdate_Tablas.setEnabled(True)
                self.actionUpdateTablas_SQLITE.setEnabled(False)

        except Exception as Error:
            pass

    def Sesion_MariaDB(self):
        self.Consulta_Entrada.clear()
        self.Consulta_Salida.clear()
        self.BasesDatos_Info.clear()
        self.Tablas_Info.clear()
        self.Numero_Filas.clear()
        # self.Salidas.setTabText(1, self.Numero_Filas.setText(""))
        # self.Salidas.setTabText(1, "Resultados de la Consulta")
        # self.Salidas.setTabText(0, "Numero Filas Devueltas")
        try:
            self.cnxn.close()

        except Exception as Error:
            pass
        Iniciar = Conexion_Maridb()
        Iniciar.exec_()
        try:
            self.server = 'localhost'
            self.database = ''
            self.username = Iniciar.username
            self.password = Iniciar.password
            try:
                # self.cnxn = sql.connect(host=self.server,
                                        # database=self.database, user=self.username, password=self.password, port=3310)
                self.cnxn = pyodbc.connect('DRIVER={MySQL ODBC 8.0 ANSI Driver};SERVER='+self.server +
                                           ';DATABASE='+self.database+';UID='+self.username+';PWD=' + self.password, port=3310)
                self.cursor = self.cnxn.cursor()
            except Exception as Error:
                QMessageBox.warning(self, "CONEXION FALLIDA",
                                    "Identificacion fallida", QMessageBox.Discard)
                self.Sesion_MariaDB()

            if(self.cnxn == False):
                QMessageBox.waring(
                    self, "ERROR", "NO se ha podido conectar a la base de datos", QMessageBox.Discard)
            else:
                self.BasesDatos_Info.show()
                self.Mostrar_Bases_Datos()
                self.actionUpdateBaseDatos.setEnabled(True)
                self.actionUpdate_Tablas.setEnabled(True)
                self.actionUpdateTablas_SQLITE.setEnabled(False)

        except Exception as Error:
            pass

    def Sesion_sqlite(self):
        Buscar_BaseDatos = Activar_BD()
        Buscar_BaseDatos.exec_()
        self.BasesDatos_Info.hide()
        self.Consulta_Entrada.clear()
        self.Consulta_Salida.clear()
        self.BasesDatos_Info.clear()
        self.Numero_Filas.clear()
        # self.Salidas.setTabText(1, self.Numero_Filas.setText(""))
        # self.Salidas.setTabText(1, "Resultados de la Consulta")
        # self.Salidas.setTabText(0, "Numero Filas Devueltas")
        self.Tablas_Info.show()
        self.Tablas_Info.clear()
        self.actionUpdateBaseDatos.setEnabled(False)
        self.actionUpdate_Tablas.setEnabled(False)
        self.actionUpdateTablas_SQLITE.setEnabled(True)
        self.database = Buscar_BaseDatos.Direccion.text()
        self.Nuevadatabase = Buscar_BaseDatos.Nueva_Base_SQLite.text()
        try:
            self.cnxn.close()
        except Exception as Error:
            pass

        if(self.database == "Aqui aparecerá el archivo de base de datos una vez seleccionado" and self.Nuevadatabase != "Introduce la direccion y el nombre de la nueva base de datos"):
            self.cnxn = sqlite3.connect(self.Nuevadatabase)
            self.cursor = self.cnxn.cursor()
            print("Has elegido la base de datos ", self.Nuevadatabase)
        elif(self.database != "Aqui aparecerá el archivo de base de datos una vez seleccionado" and self.Nuevadatabase == "Introduce la direccion y el nombre de la nueva base de datos"):
            self.cnxn = sqlite3.connect(self.database)
            self.cursor = self.cnxn.cursor()
            print("Has elegido la base de datos ", self.database)

        Tablas = "select distinct name,type from sqlite_master where type='table' or type='procedure' or type='view' "
        self.cursor.execute(Tablas)
        self.resultado = self.cursor.fetchall()
        if(self.resultado != []):
            for each in self.resultado:
                Nombre_Tabla = each
                self.Tablas_Info.insertTopLevelItems(
                    0, [QTreeWidgetItem(Nombre_Tabla)])

    def Sesion_Pajaro_Fuego(self):
        Cargar_Sesion = Usuario_FireBird()
        Cargar_Sesion.exec_()
        self.BasesDatos_Info.hide()
        self.Consulta_Entrada.clear()
        self.Consulta_Salida.clear()
        self.BasesDatos_Info.clear()
        self.Salidas.setTabText(1, self.Numero_Filas.setText(""))
        self.Salidas.setTabText(1, "Resultados de la Consulta")
        self.Salidas.setTabText(0, "Numero Filas Devueltas")
        self.Tablas_Info.show()
        self.Tablas_Info.clear()
        self.Numero_Filas.clear()
        self.actionUpdateBaseDatos.setEnabled(False)
        self.actionUpdate_Tablas.setEnabled(True)
        self.actionUpdateTablas_SQLITE.setEnabled(False)

        try:
            self.Nombre_Acceso.clear()
            self.Clave_Acceso.clear()
            self.DB_Acceso.clear()

        except Exception as Error:
            pass
        try:
            self.Nombre_Acceso = Cargar_Sesion.Nombre_Usuario
            self.Clave_Acceso = Cargar_Sesion.Clave_Usuario
            self.database = Cargar_Sesion.dsn
            self.cnxn = fdb.connect(
                self.database, self.Nombre_Acceso, self.Clave_Acceso)
            self.cursor = self.cnxn.cursor()
            Tablas = "SELECT RDB$RELATION_NAME FROM RDB$RELATIONS WHERE RDB$SYSTEM_FLAG=0"
            self.cursor.execute(Tablas)
            self.resultado = self.cursor.fetchall()
            if(self.resultado != []):
                for each in self.resultado:
                    Nombre_Tabla = each
                    self.Tablas_Info.insertTopLevelItems(
                        0, [QTreeWidgetItem(Nombre_Tabla)])

        except Exception as Error:
            QMessageBox.warning(
                self, "ERROR", "Identificacion fallida", QMessageBox.Discard)
            Opcion = QMessageBox.question(
                self, "Otro Intento", "Quieres Volver a intentarlo?", QMessageBox.Yes | QMessageBox.No)
            if(Opcion == QMessageBox.Yes):
                self.Sesion_Pajaro_Fuego()
            else:
                pass

            try:

                Cargar_Sesion.hide()
            except Exception as Error:
                pass

    def Sesion_SQLSERVER(self):
        self.Consulta_Entrada.clear()
        self.Consulta_Salida.clear()
        self.BasesDatos_Info.clear()
        self.Salidas.setTabText(1, self.Numero_Filas.setText(""))
        self.Salidas.setTabText(1, "Resultados de la Consulta")
        self.Salidas.setTabText(0, "Numero Filas Devueltas")
        self.Tablas_Info.clear()
        self.Numero_Filas.clear()

        try:
            self.database.clear()
            self.username.clear()
            self.password.clear()
            self.cnxn.close()
        except Exception as Error:
            pass
            Iniciar = Ventana_Conexion()
            Iniciar.exec_()
            try:
                self.server = 'localhost'
                self.database = ''
                self.username = Iniciar.username
                self.password = Iniciar.password
                try:
                    self.cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL SERVER};SERVER='+self.server +
                                               ';DATABASE='+self.database+';UID='+self.username+';PWD=' + self.password, autocommit=True)
                    self.cursor = self.cnxn.cursor()
                except pyodbc.Error:
                    QMessageBox.warning(self, "CONEXION FALLIDA",
                                        "Identificacion fallida", QMessageBox.Discard)
                    self.Sesion_SQLSERVER()
                if(self.cnxn == False):
                    QMessageBox.waring(
                        self, "ERROR", "NO se ha podido conectar a la base de datos", QMessageBox.Discard)
                else:

                    self.BasesDatos_Info.show()
                    self.Bases_Datos_Server()
                    self.actionUpdateBaseDatos.setEnabled(True)
                    self.actionUpdate_Tablas.setEnabled(True)
                    self.actionUpdateTablas_SQLITE.setEnabled(False)
            except Exception as Error:
                pass
                # QMessageBox.warning(self, "CONEXION FALLIDA",
                # "Necesitas identificarte para acceder", QMessageBox.Discard)
                # self.Sesion_SQL()

    def Sesion_PostgreSQL(self):
        # print("Esta funcion corresponde al servidor PostgreSQL")
        self.Consulta_Entrada.clear()
        self.Consulta_Salida.clear()
        self.BasesDatos_Info.clear()
        self.BasesDatos_Info.show()
        self.Tablas_Info.show()
        self.Tablas_Info.clear()
        self.Numero_Filas.clear()

        try:
            self.database.clear()
            self.username.clear()
            self.password.clear()
            self.cnxn.close()

        except Exception as Error:
            pass

            Llamar = Inicio_Postgre()
            Llamar.exec_()

            try:
                self.username = Llamar.Nombre_Acceso

                self.password = Llamar.Clave_Acceso
                self.database = Llamar.Database

                print("Nombre Usuario " + self.username+" Contraseña " +
                      self.password+" Base de datos elegida "+str(self.database))
                self.cnxn = psycopg2.connect(
                    user=self.username, password=self.password, database=self.database)
                self.cnxn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
                self.cursor = self.cnxn.cursor()
                Tablas = "Select Tablename from pg_catalog.pg_tables where schemaname != 'pg_catalog' and schemaname != 'information_schema'"
                self.cursor.execute(Tablas)
                self.resultado = self.cursor.fetchall()

                if(self.resultado == []):

                    # self.Tablas_Info.hide()

                    QMessageBox.warning(
                        self, "Vacio", "La base de datos no contiene tablas", QMessageBox.Ok)

                else:
                    self.BasesDatos_Info.hide()
                    self.actionUpdateBaseDatos.setEnabled(False)
                    self.actionUpdate_Tablas.setEnabled(True)
                    self.actionUpdateTablas_SQLITE.setEnabled(False)
                    for each in self.resultado:
                        Nombre_Tabla = each
                        self.Tablas_Info.insertTopLevelItems(
                            0, [QTreeWidgetItem(Nombre_Tabla)])

            except Exception as Error:
                QMessageBox.warning(self, "ERROR EN LOS DATOS",
                                    "El usuario/Contraseña no existen", QMessageBox.Discard)
                Opcion = QMessageBox.question(
                    self, "Otro Intento", "Quieres Volver a intentarlo?", QMessageBox.Yes | QMessageBox.No)

                if(Opcion == QMessageBox.Yes):
                    # event.accept()
                    self.Sesion_PostgreSQL()

                else:
                    pass

                try:
                    self.cnxn.close()
                    Llamar.hide()

                except Exception as Error:

                    try:
                        self.cnxn.close()

                    except Exception as Error:
                        pass

    def Ayuda(self):

        Mensaje = "Pulsa F5 para ejecutar las Consultas Introducidas"
        QMessageBox.warning(self, "AYUDA", Mensaje, QMessageBox.Ok)

    def Mostrar_Resultado(self):
        self.Consulta = self.Consulta_Entrada.toPlainText()

        # self.cursor.execute(Consulta)
        try:
            fdb.create_database(self.Consulta)

        except:
            try:
                self.cursor.execute(self.Consulta)

            except Exception as Error:
                if(str(Error) == "'builtin_function_or_method' object has no attribute 'execute'"):
                    QMessageBox.warning(
                        self, "No se ha podido realizar la operacion", "No has iniciado sesión", QMessageBox.Ok)
                else:
                    QMessageBox.warning(
                        self, "No se ha podido realizar la operacion", str(Error), QMessageBox.Ok)

            try:
                self.resultado = self.cursor.fetchall()
                self.Salidas.setTabText(1, self.Numero_Filas.setText(
                    "Se han devuelto "+str(len(self.resultado))))
                self.Salidas.setTabText(1, "Resultado de las Consultas")
                if(self.resultado != []):
                    self.cabeceras = [[x[0] for x in self.cursor.description]]
                    self.headers = [x[0] for x in self.cursor.description]
                    self.createTable()
                    self.Salidas.setTabText(1, "Resultado de las Consultas")

                else:
                    self.Salidas.setTabText(1, "Resultado de las Consultas")
                    QMessageBox.warning(
                        self, "", "No hay datos que mostrar", QMessageBox.Ok)
                    self.Consulta_Salida.clear()

            except Exception as Error:
                pass

            try:

                self.cnxn.commit()

            except Exception as Error:
                self.Consulta_Salida.clear()
                pass

    def RecargarBases(self):
        try:
            if(self.cnxn):

                if(not self.Mostrar_Bases_Datos()):
                    # self.Mostrar_Bases_Datos()
                    # else:
                    self.Bases_Datos_Server()
        except Exception:
            QMessageBox.warning(
                self, "ERROR", "NO has iniciado sesión", QMessageBox.Discard)

    def createTable(self):
        self.Salidas.setTabText(1, "Resultado de las Consultas")
        self.Consulta_Salida.setRowCount(len(self.resultado))
        self.Consulta_Salida.setColumnCount(len(self.resultado[0]))
        row = 0

        for each in self.resultado:

            for val in range(len(each)):
                self.Consulta_Salida.setItem(
                    row, val, QTableWidgetItem(str(each[val])))

            row += 1
            self.Consulta_Salida.setHorizontalHeaderLabels(self.headers)
        # print("El resultado de la salida es ", len(self.resultado))

    def keyPressEvent(self, event):

        if event.key() == 16777268:  # F5
            self.Mostrar_Resultado()
            # print(self.Consulta)

        else:
            super(Ventana_Principal, self).keyPressEvent(event)

    def Mostrar_Bases_Datos(self):
        self.BasesDatos_Info.clear()
        self.Tablas_Info.hide()
        Salida_Bases = "Show databases"

        try:
            self.cursor.execute(Salida_Bases)
            self.resultado = self.cursor.fetchall()

            for element in self.resultado:
                name = element

                # Insertar la fila
                self.BasesDatos_Info.insertTopLevelItems(
                    0, [QTreeWidgetItem(name)])
            return True
        except Exception as Error:
            return False

    def Ver_Tablas(self):
        try:
            self.Tablas_Info.clear()
            self.Tablas_Info.show()
            self.Bases_Datos_Activas = []
            Nombre_Base = " "
            Nombre_Base = self.BasesDatos_Info.selectedItems()
            for each in range(len(Nombre_Base)):
                self.Bases_Datos_Activas.append(
                    self.BasesDatos_Info.selectedItems()[each].text(each))
            if(self.Bases_Datos_Activas == []):

                QMessageBox.warning(
                    self, "VACIO", "Tienes que seleccionar una base de datos", QMessageBox.Discard)
            else:
                # print(str(self.Bases_Datos_Activas[0]))
                try:
                    Mostrar_Tablas = "Show tables from " + \
                        str(self.Bases_Datos_Activas[0])
                    self.cursor.execute(Mostrar_Tablas)
                    self.resultado = self.cursor.fetchall()

                    if(self.resultado != []):

                        for element in self.resultado:
                            name = element
                            self.Tablas_Info.insertTopLevelItems(
                                0, [QTreeWidgetItem(name)])

                    else:
                        self.Tablas_Info.hide()
                        QMessageBox.warning(self, "Vacio", "La base de datos " +
                                            str(self.Bases_Datos_Activas[0])+" NO tiene tablas", QMessageBox.Discard)

                except Exception as Error:

                    try:
                        Activar = "Use "+str(self.Bases_Datos_Activas[0])
                        # print(Activar)
                        self.cursor.execute(Activar).commit()
                        Mostrar_Tablas = "SELECT name from sys.Tables"
                        self.cursor.execute(Mostrar_Tablas)
                        self.resultado = self.cursor.fetchall()

                        if(self.resultado != []):

                            for element in self.resultado:
                                name = element
                                self.Tablas_Info.insertTopLevelItems(
                                    0, [QTreeWidgetItem(name)])
                        else:
                            self.Tablas_Info.hide()
                            QMessageBox.warning(
                                self, "Vacio", "La base de datos  NO tiene tablas", QMessageBox.Discard)

                    except Exception as Error:

                        QMessageBox.warning(
                            self, "ERROR", "Fallo al mostrar las tablas de la base de datos", QMessageBox.Discard)

        except Exception as error:
            pass

    def Bases_Datos_Server(self):
        self.BasesDatos_Info.clear()
        self.Tablas_Info.hide()
        Salida_Bases = "select name from sys.databases"

        try:
            self.cursor.execute(Salida_Bases)
            self.resultado = self.cursor.fetchall()

            for element in self.resultado:
                name = element

                # Insertar la fila
                self.BasesDatos_Info.insertTopLevelItems(
                    0, [QTreeWidgetItem(name)])

        except Exception as Error:
            pass

    def RecargarTablas(self):
        try:
            if(self.cnxn):
                self.Tablas_Info.clear()
                self.Tablas_Info.show()
                # MYSQL
                try:
                    self.Tablas_Info.clear()
                    self.Bases_Datos_Activas = []
                    Nombre_Base = " "
                    Nombre_Base = self.BasesDatos_Info.selectedItems()
                    for each in range(len(Nombre_Base)):
                        self.Bases_Datos_Activas.append(
                            self.BasesDatos_Info.selectedItems()[each].text(each))

                    # print(str(self.Bases_Datos_Activas[0]))
                except:
                    pass

                try:
                    Mostrar_Tablas = "Show tables from " + \
                        str(self.Bases_Datos_Activas[0])
                    self.cursor.execute(Mostrar_Tablas)
                    self.resultado = self.cursor.fetchall()

                    if(self.resultado != []):

                        for element in self.resultado:
                            name = element
                            self.Tablas_Info.insertTopLevelItems(
                                0, [QTreeWidgetItem(name)])

                    else:
                        self.Tablas_Info.hide()
                        QMessageBox.warning(self, "Vacio", "La base de datos " +
                                            str(self.Bases_Datos_Activas[0])+" NO tiene tablas", QMessageBox.Discard)

                except Exception as Error:
                        # SQL SERVER
                    try:
                        self.Tablas_Info.clear()
                        Activar = "Use "+str(self.Bases_Datos_Activas[0])

                        self.cursor.execute(Activar).commit()
                        Mostrar_Tablas = "SELECT name from sys.Tables"
                        self.cursor.execute(Mostrar_Tablas)
                        self.resultado = self.cursor.fetchall()

                        if(self.resultado != []):

                            for element in self.resultado:
                                name = element
                                self.Tablas_Info.insertTopLevelItems(
                                    0, [QTreeWidgetItem(name)])
                        else:
                            self.Tablas_Info.hide()
                            QMessageBox.warning(
                                self, "Vacio", "La base de datos  NO tiene tablas", QMessageBox.Discard)

                    except Exception as Error:
                        # FIREBIRD
                        try:
                            self.Tablas_Info.clear()
                            Tablas = "SELECT RDB$RELATION_NAME FROM RDB$RELATIONS WHERE RDB$SYSTEM_FLAG=0"
                            self.cursor.execute(Tablas)
                            self.resultado = self.cursor.fetchall()
                            if(self.resultado != []):
                                for each in self.resultado:
                                    Nombre_Tabla = each
                                    self.Tablas_Info.insertTopLevelItems(
                                        0, [QTreeWidgetItem(Nombre_Tabla)])

                        except Exception as Error:
                                # SQLSERVER
                            try:
                                self.Tablas_Info.clear()
                                Activar = "Use " + \
                                    str(self.Bases_Datos_Activas[0])

                                self.cursor.execute(Activar).commit()
                                Mostrar_Tablas = "SELECT name from sys.Tables"
                                self.cursor.execute(Mostrar_Tablas)
                                self.resultado = self.cursor.fetchall()

                                if(self.resultado != []):

                                    for element in self.resultado:
                                        name = element
                                        self.Tablas_Info.insertTopLevelItems(
                                            0, [QTreeWidgetItem(name)])
                                else:
                                    self.Tablas_Info.hide()
                                    QMessageBox.warning(
                                        self, "Vacio", "La base de datos  NO tiene tablas", QMessageBox.Discard)

                            except Exception as Error:
                                                                                                                                                             # POSTGRESQL
                                try:
                                    self.Tablas_Info.clear()
                                    Tablas = "Select Tablename from pg_catalog.pg_tables where schemaname != 'pg_catalog' and schemaname != 'information_schema'"
                                    self.cursor.execute(Tablas)
                                    self.resultado = self.cursor.fetchall()

                                    if(self.resultado == []):

                                        # self.Tablas_Info.hide()

                                        QMessageBox.warning(
                                            self, "Vacio", "La base de datos no contiene tablas", QMessageBox.Ok)

                                    else:
                                        self.BasesDatos_Info.hide()
                                        for each in self.resultado:
                                            Nombre_Tabla = each
                                            self.Tablas_Info.insertTopLevelItems(
                                                0, [QTreeWidgetItem(Nombre_Tabla)])
                                except Exception as Error:
                                    self.Tablas_Info.hide()
                                    QMessageBox.warning(
                                        self, "VACIO", "NO tienes seleccionada ninguna base de datos", QMessageBox.Discard)

        except Exception:
            QMessageBox.warning(
                self, "ERROR", "NO has iniciado sesión", QMessageBox.Discard)

    def RecargarSQLITE(self):
        try:
            self.Tablas_Info.clear()
            self.cnxn = sqlite3.connect(self.database)
            self.cursor = self.cnxn.cursor()
            Tablas = "select distinct name,type from sqlite_master where type='table' or type='procedure' or type='view' "
            self.cursor.execute(Tablas)
            self.resultado = self.cursor.fetchall()
            if(self.resultado != []):
                for each in self.resultado:
                    Nombre_Tabla = each
                    self.Tablas_Info.insertTopLevelItems(
                        0, [QTreeWidgetItem(Nombre_Tabla)])
        except Exception as Error:
            QMessageBox.warning(
                self, "ERROR", "No estas conectado a ninguna base de datos", QMessageBox.Discard)

    def Cambiar_Letra(self):
        from CSS_Letra import Estilo_Letra
        Letra = Estilo_Letra()
        Letra.exec_()
        try:
            self.Fuente_Letra1 = Letra.Fuente_Elegida1
            print("La fuente elegida es ", self.Fuente_Letra1)
        except Exception as Error:
            pass

        try:
            self.Fuente_Estilo1 = Letra.Fuente_Estilo1
            print("El estilo Elegido es ", self.Fuente_Estilo1)
        except Exception as Error:
            pass

        try:
            self.Fuente_Tamanio1 = Letra.Fuente_Size
            print("El tamaño elegido es ", self.Fuente_Tamanio1)
        except Exception as Error:
            pass
        try:
            self.Color_Letra1 = Letra.Color_Letra1
            print("El color de la Letra elegida es "+self.Color_Letra1)

        except Exception as Error:
            pass

        try:
            self.Color_Fondo1 = Letra.Color_Fondo1
            print("El fondo es de Color "+self.Color_Fondo1)

        except Exception as Error:
            pass

        try:
            self.BasesDatos_Info.setStyleSheet(
                "QTreeWidget,QHeaderView::section{"+
                "font-family: "+str(self.Fuente_Letra1) +
                ";font-size: " + str(self.Fuente_Tamanio1) + "px;" +
                "font-weight: " + str(self.Fuente_Estilo1) +
                ";color: "+str(self.Color_Letra1) +
                ";background-color: "+str(self.Color_Fondo1)+";}")
        except Exception as Error:
            pass

        try:
            self.Fuente_Letra2 = Letra.Fuente_Elegida2
            print("La fuente elegida es ", self.Fuente_Letra2)
        except Exception as Error:
            pass

        try:
            self.Fuente_Estilo2 = Letra.Fuente_Estilo2
            print("El estilo Elegido es ", self.Fuente_Estilo2)
        except Exception as Error:
            pass

        try:
            self.Fuente_Tamanio2 = Letra.Fuente_Size2
            print("El tamaño elegido es ", self.Fuente_Tamanio2)
        except Exception as Error:
            pass
        try:
            self.Color_Letra2 = Letra.Color_Letra2
            print("El color de la Letra elegida es "+self.Color_Letra2)

        except Exception as Error:
            pass

        try:
            self.Color_Fondo2 = Letra.Color_Fondo2
            print("El fondo es de Color "+self.Color_Fondo2)

        except Exception as Error:
            pass

        try:
            self.Tablas_Info.setStyleSheet( 
                "QTreeWidget,QHeaderView::section{"+
                "font-family: "+str(self.Fuente_Letra2) +
                ";font-size: " + str(self.Fuente_Tamanio2) + "px;" +
                "font-weight: " + str(self.Fuente_Estilo2) +
                ";color: "+str(self.Color_Letra2) +
                ";background-color: "+str(self.Color_Fondo2)+",}")
        except Exception as Error:
            pass

        try:
            self.Fuente_Letra3 = Letra.Fuente_Elegida3
            print("La fuente elegida es ", self.Fuente_Letra3)
        except Exception as Error:
            pass

        try:
            self.Fuente_Estilo3 = Letra.Fuente_Estilo3
            print("El estilo Elegido es ", self.Fuente_Estilo3)
        except Exception as Error:
            pass

        try:
            self.Fuente_Tamanio3 = Letra.Fuente_Size3
            print("El tamaño elegido es ", self.Fuente_Tamanio3)
        except Exception as Error:
            pass
        try:
            self.Color_Letra3 = Letra.Color_Letra3
            print("El color de la Letra elegida es "+self.Color_Letra3)
        except Exception as Error:
            pass

        try:
            self.Color_Fondo3 = Letra.Color_Fondo3
            print("El fondo es de Color "+self.Color_Fondo3)
        except Exception as Error:
            pass

        try:
            self.Consulta_Entrada.setStyleSheet(
                "font-family: "+str(self.Fuente_Letra3) +
                ";font-size: " + str(self.Fuente_Tamanio3) + "px;" +
                "font-weight: " + str(self.Fuente_Estilo3) +
                ";color: "+str(self.Color_Letra3) +
                ";background-color: "+str(self.Color_Fondo3))
        except Exception as Error:
            pass

        try:
            self.Fuente_Letra4 = Letra.Fuente_Elegida4
            print("La fuente elegida es ", self.Fuente_Letra4)
        except Exception as Error:
            pass

        try:
            self.Fuente_Estilo4 = Letra.Fuente_Estilo4
            print("El estilo Elegido es ", self.Fuente_Estilo4)
        except Exception as Error:
            pass

        try:
            self.Fuente_Tamanio4 = Letra.Fuente_Size4
            print("El tamaño elegido es ", self.Fuente_Tamanio4)
        except Exception as Error:
            pass
        try:
            self.Color_Letra4 = Letra.Color_Letra4
            print("El color de la Letra elegida es "+self.Color_Letra4)
        except Exception as Error:
            pass

        try:
            self.Color_Fondo4 = Letra.Color_Fondo4
            print("El fondo es de Color "+self.Color_Fondo4)
        except Exception as Error:
            pass

        try:
            self.Numero_Filas.setStyleSheet(
                "font-family: "+str(self.Fuente_Letra4) +
                ";font-size: " + str(self.Fuente_Tamanio4) + "px;" +
                "font-weight: " + str(self.Fuente_Estilo4) +
                ";color: "+str(self.Color_Letra4) +
                ";background-color: "+str(self.Color_Fondo4))

            self.Consulta_Salida.setStyleSheet(
                "QTableWidget,QHeaderView::section{"+
                "font-family: "+str(self.Fuente_Letra4) +
                ";font-size: " + str(self.Fuente_Tamanio4) + "px;" +
                "font-weight: " + str(self.Fuente_Estilo4) +
                ";color: "+str(self.Color_Letra4) +
                ";background-color: "+str(self.Color_Fondo4)+";}")
        except Exception as Error:
            pass
            
    def Problemas_Vision(self):
    
        self.BasesDatos_Info.setStyleSheet(
                "QTreeWidget,QHeaderView::section{"+
                "font-family:Arial;" +
                "font-size:30px;" +
                "font-weight:Normal;"+
                "color:green;"+
                "background-color:black;}")
                
        self.Tablas_Info.setStyleSheet(
                "QTreeWidget,QHeaderView::section{"+
                "font-family:Arial;"+
                "font-size:30px; " +
                "font-weight:Normal;"+
                "color:green; "+
                "background-color:black;}")
                
                
        self.Consulta_Entrada.setStyleSheet(
                "font-family:Arial ;"+
                "font-size:30px ;"+
                "font-weight:Normal ;"+
                "color:green ;"+
                "background-color:black ;")
        self.Numero_Filas.setStyleSheet(
                "font-family:Arial; "+
                "font-size: 30px;"+
                "font-weight:Normal;" +
                "color:green ;"+
                "background-color:black ;")

        self.Consulta_Salida.setStyleSheet(
                "QTableWidget,QHeaderView::section{"+
                "font-family:Arial ;"+
                "font-size: 30px ;"+
                "font-weight:Normal ;"+
                "color:green ;"+
                "background-color:black ;}")

    def Conf_Daltonicos(self):
        self.BasesDatos_Info.setStyleSheet(
                "QTreeWidget,QHeaderView::section{"
                "font-family:Arial;" +
                "font-size:20px;" +
                "font-weight:Normal;"+
                "color:black;"+
                "background-color:#7fa0b5;}")
                
        self.Tablas_Info.setStyleSheet(
                "QTreeWidget ,QHeaderView::section{"+
                "font-family:Arial;"+
                "font-size:20px; " +
                "font-weight:Normal;"+
                "color:black; "+
                "background-color:#7fa0b5;}")
                
                
        self.Consulta_Entrada.setStyleSheet(
                "font-family:Arial ;"+
                "font-size:20px ;"+
                "font-weight:Normal ;"+
                "color:black ;"+
                "background-color:#7fa0b5 ;")
        self.Numero_Filas.setStyleSheet(
                "font-family:Arial; "+
                "font-size: 20px;"+
                "font-weight:Normal;" +
                "color:black ;"+
                "background-color:#7fa0b5 ;")

        self.Consulta_Salida.setStyleSheet(
                "QTableWidget,QHeaderView::section{"+
                "font-family:Arial ;"+
                "font-size: 20px ;"+
                "font-weight:Normal ;"+
                "color:black ;"+
                "background-color:#7fa0b5 ;}")
                
    def Graficos_Estadisticas(self):
        Load_Graphics = Obtein_Result()
        Load_Graphics.exec_()

    def Exportar_SQL(self):
        Activar_Copia = Copia_SQL()
        Activar_Copia.exec_()

    def Importar_SQL(self):
        Restaurar_Copia = Retornar_SQL()
        Restaurar_Copia.exec_()

    def Exportar_MariaDb(self):
        Activar_Copia = Copia_MariaDB()
        Activar_Copia.exec_()

    def Importar_MariaDb(self):
        Restaurar_Copia = Retornar_MariaDb()
        Restaurar_Copia.exec_()

    def Exportar_SQL2017(self):
        Activar_Copia = Copia_SQL2017()
        Activar_Copia.exec_()

    def Importar_SQL2017(self):
        Restaurar_Copia = Restaurar_SQL2017()
        Restaurar_Copia.exec_()

    def Exportar_Postgre(self):
        Activar_Copia = Copia_Postgre()
        Activar_Copia.exec_()

    def Importar_Postgre(self):
        Restaurar_Copia = Restaurar_Postgre()
        Restaurar_Copia.exec_()

    def Guardar_Resultado(self):
        try:
            Almacenar = Guardar_Opciones(self.resultado, self.cabeceras)
            Almacenar.exec_()

        except Exception as Error:
            QMessageBox.warning(
                self, "VACIO", "NECESITAS conectarte a la base de datos y tener resultados que guardar", QMessageBox.Discard)
                
    def Buscar_Palabra(self):
        Mostrar_Palabra=Palabra_Aparece()
        Mostrar_Palabra.exec_()
        
    def Tendencia_Anual(self):
        Mas_Buscado=Tendencia_Global()
        Mas_Buscado.exec_()

    def Api_Rest(self):
        Llamada=APIWEB()
        Llamada.exec_()

    def Agregar_Usuario(self):
        Crear=Nuevo_Usuario()
        Crear.exec_()

    def Detalles_Usuario(self):
        Detalles=Usuario_Detalle()
        Detalles.exec_()
    def Crear_Base(self):
        Crear_Base = Ventana_Ayuda()
        Crear_Base.Crear_Base_Datos()
        Crear_Base.exec_()

    def Activar_Base(self):
        Activar_Base = Ventana_Ayuda()
        Activar_Base.Activar_Base_Datos()
        Activar_Base.exec_()

    def Borrar_Base(self):
        Borrar_Base = Ventana_Ayuda()
        Borrar_Base.Borrar_Base_Datos()
        Borrar_Base.exec_()

    def Ver_Bases_Datos_Disponibles(self):
        Ver_Bases_Datos = Ventana_Ayuda()
        Ver_Bases_Datos.Listar_Base_Datos()
        Ver_Bases_Datos.exec_()

    def Crear_Tabla(self):
        Nueva_Tabla = Ventana_Ayuda()
        Nueva_Tabla.Crear_Nueva_Tabla()
        Nueva_Tabla.exec_()

    def Ver_Tablas_Disponibles(self):
        Ver_Tablas = Ventana_Ayuda()
        Ver_Tablas.Ver_Tablas_Existentes()
        Ver_Tablas.exec_()

    def Estructura_Tabla(self):
        Describir_Tablas = Ventana_Ayuda()
        Describir_Tablas.Describir_Tablas()
        Describir_Tablas.exec_()

    def Insertar_Datos(self):
        Insertar_Informacion = Ventana_Ayuda()
        Insertar_Informacion.Insertar_Datos()
        Insertar_Informacion.exec_()

    def Actualizar_Datos(self):
        Actualizar_Informacion = Ventana_Ayuda()
        Actualizar_Informacion.Cambiar_Datos()
        Actualizar_Informacion.exec_()

    def Borrar_Campos(self):
        Quitar_Registro = Ventana_Ayuda()
        Quitar_Registro.Borrar_Registro()
        Quitar_Registro.exec_()

    def Filtrar_Campos(self):
        Filtrar_Registro = Ventana_Ayuda()
        Filtrar_Registro.Filtrar_Tabla()
        Filtrar_Registro.exec_()

    def Drop_Table(self):
        Eliminar_Tabla = Ventana_Ayuda()
        Eliminar_Tabla.Quitar_Tabla()
        Eliminar_Tabla.exec_()

    def Truncar_Tabla(self):
        Limpiar_Tabla = Ventana_Ayuda()
        Limpiar_Tabla.Vaciar_Tabla()
        Limpiar_Tabla.exec_()

    def Crear_Vista(self):
        Realizar_Vista = Ventana_Ayuda()
        Realizar_Vista.Nueva_Vista()
        Realizar_Vista.exec_()

    def Borrar_Vista(self):
        Eliminar_Vista = Ventana_Ayuda()
        Eliminar_Vista.Eliminar_Vista()
        Eliminar_Vista.exec_()

    def Consultar_Vistas(self):
        Visualizar_Vistas = Ventana_Ayuda()
        Visualizar_Vistas.Vistas_Existentes()
        Visualizar_Vistas.exec_()

    def Crear_Procedimiento(self):
        Nuevo_Procedimiento = Ventana_Ayuda()
        Nuevo_Procedimiento.Crear_Procedimiento()
        Nuevo_Procedimiento.exec_()

    def Llamar_Procedimiento(self):
        Activar_Procedimiento = Ventana_Ayuda()
        Activar_Procedimiento.Llamar_Procedimiento()
        Activar_Procedimiento.exec_()

    def Ver_Procedimientos(self):
        Consultar_Procedimientos = Ventana_Ayuda()
        Consultar_Procedimientos.Ver_Procedimientos_Existentes()
        Consultar_Procedimientos.exec_()

    def Borrar_Procedimiento(self):
        Eliminar_Procedimientos = Ventana_Ayuda()
        Eliminar_Procedimientos.Eliminar_Procedimiento()
        Eliminar_Procedimientos.exec_()

    def Crear_Funciones(self):
        Nueva_Funcion = Ventana_Ayuda()
        Nueva_Funcion.Nueva_Funcion()
        Nueva_Funcion.exec_()

    def Ver_Funciones(self):
        Visualizar_Funciones = Ventana_Ayuda()
        Visualizar_Funciones.Funciones_Existentes()
        Visualizar_Funciones.exec_()

    def Llamar_Funciones(self):
        Activar_Funcion = Ventana_Ayuda()
        Activar_Funcion.Llamar_Funcion()
        Activar_Funcion.exec_()

    def Borrar_Funciones(self):
        Eliminar_Funciones = Ventana_Ayuda()
        Eliminar_Funciones.Eliminar_Funcion()
        Eliminar_Funciones.exec_()

    def Limpiar_Tablas(self):
        self.Tablas_Info.clear()
        # self.Tablas_Info.hide()

    def Limpiar_Consultas_Entrada(self):
        self.Consulta_Entrada.clear()

    def Limpiar_Consultas_Salida(self):
        self.Consulta_Salida.clear()
        self.Consulta_Salida.clear()

    def Limpiar_Num_Filas(self):
        self.Numero_Filas.clear()

    def Crear_Trigger(self):
        Nuevo_Trigger = Ventana_Ayuda()
        Nuevo_Trigger.Crear_Trigger()
        Nuevo_Trigger.exec_()

    def Borrar_Trigger(self):
        Eliminar_Triggers = Ventana_Ayuda()
        Eliminar_Triggers.Eliminar_Trigger()
        Eliminar_Triggers.exec_()

    def Ver_Triggers(self):
        Visualizar_Triggers = Ventana_Ayuda()
        Visualizar_Triggers.Ver_Triggers_Existentes()
        Visualizar_Triggers.exec_()

    def Crear_Usuario_SQL(self):
        Nuevo_Usuario = Ventana_Ayuda()
        Nuevo_Usuario.Nuevo_Usuario_SQL()
        Nuevo_Usuario.exec_()

    def Asignar_Permisos_SQL(self):
        Dar_Permiso = Ventana_Ayuda()
        Dar_Permiso.Asignar_Privilegios_SQL()
        Dar_Permiso.exec_()

    def Quitar_Privilegios_SQL(self):
        Quitar_Permisos = Ventana_Ayuda()
        Quitar_Permisos.Revokar_Privilegios_SQL()
        Quitar_Permisos.exec_()

    def Eliminar_Usuario_SQL(self):
        Borrar_Usuario = Ventana_Ayuda()
        Borrar_Usuario.Quitar_Usuario_SQL()
        Borrar_Usuario.exec_()

    def Usuarios_Existentes_SQL(self):
        UsuariosSQL = Ventana_Ayuda()
        UsuariosSQL.Listar_Usuarios_SQL()
        UsuariosSQL.exec_()

    def Crear_Usuario_FDB(self):
        Nuevo_Usuario = Ventana_Ayuda()
        Nuevo_Usuario.Nuevo_Usuario_Firebird()
        Nuevo_Usuario.exec_()

    def Asignar_Permisos_FDB(self):
        Dar_Permiso = Ventana_Ayuda()
        Dar_Permiso.Asignar_Privilegios_Firebird()
        Dar_Permiso.exec_()

    def Quitar_Privilegios_FDB(self):
        Quitar_Permisos = Ventana_Ayuda()
        Quitar_Permisos.Revokar_Privilegios_Firebird()
        Quitar_Permisos.exec_()

    def Eliminar_Usuario_FDB(self):
        Borrar_Usuario = Ventana_Ayuda()
        Borrar_Usuario.Quitar_Usuario_Firebird()
        Borrar_Usuario.exec_()

    def Usuarios_Existentes_FDB(self):
        UsuariosSQL = Ventana_Ayuda()
        UsuariosSQL.Listar_Usuarios_Firebird()
        UsuariosSQL.exec_()

    def Crear_Usuario_Server(self):
        Nuevo_Usuario = Ventana_Ayuda()
        Nuevo_Usuario.Nuevo_Usuario_Server()
        Nuevo_Usuario.exec_()

    def Eliminar_Usuario_Server(self):
        Borrar_Usuario = Ventana_Ayuda()
        Borrar_Usuario.Quitar_Usuario_Server()
        Borrar_Usuario.exec_()

    def Asignar_Permisos_Server(self):
        Dar_Permiso = Ventana_Ayuda()
        Dar_Permiso.Asignar_Privilegios_Server()
        Dar_Permiso.exec_()

    def Quitar_Privilegios_Server(self):
        Quitar_Permisos = Ventana_Ayuda()
        Quitar_Permisos.Revokar_Privilegios_Server()
        Quitar_Permisos.exec_()

    def Usuarios_Existentes_Server(self):
        UsuariosSQL = Ventana_Ayuda()
        UsuariosSQL.Listar_Usuarios_Server()
        UsuariosSQL.exec_()

    def Crear_Usuario_Postgre(self):
        Nuevo_Usuario = Ventana_Ayuda()
        Nuevo_Usuario.Nuevo_Usuario_Postgre()
        Nuevo_Usuario.exec_()

    def Eliminar_Usuario_Postgre(self):
        Borrar_Usuario = Ventana_Ayuda()
        Borrar_Usuario.Quitar_Usuario_Postgre()
        Borrar_Usuario.exec_()

    def Asignar_Permisos_Postgre(self):
        Dar_Permiso = Ventana_Ayuda()
        Dar_Permiso.Asignar_Privilegios_Postgre()
        Dar_Permiso.exec_()

    def Quitar_Privilegios_Postgre(self):
        Quitar_Permisos = Ventana_Ayuda()
        Quitar_Permisos.Revokar_Privilegios_Postgre()
        Quitar_Permisos.exec_()

    def Usuarios_Existentes_Postgre(self):
        UsuariosSQL = Ventana_Ayuda()
        UsuariosSQL.Listar_Usuarios_Postgre()
        UsuariosSQL.exec_()

    def Ver_Bases_Datos_DisponiblesServer(self):
        Ver_Bases_Datos = Ventana_Ayuda()
        Ver_Bases_Datos.Listar_Base_DatosServer()
        Ver_Bases_Datos.exec_()

    def Ver_Bases_Datos_DisponiblesPostgre(self):
        Ver_Bases_Datos = Ventana_Ayuda()
        Ver_Bases_Datos.Listar_Base_DatosPostgre()
        Ver_Bases_Datos.exec_()

    def Crear_BaseFirebird(self):
        Crear_Base = Ventana_Ayuda()
        Crear_Base.Crear_Base_Datos_Firebird()
        Crear_Base.exec_()

    def Ver_Tablas_DisponiblesSQLITE(self):
        Ver_Tablas = Ventana_Ayuda()
        Ver_Tablas.Ver_Tablas_ExistentesSQLITE()
        Ver_Tablas.exec_()

    def Estructura_TablaSQLITE(self):
        Describir_Tablas = Ventana_Ayuda()
        Describir_Tablas.Describir_TablasSQLITE()
        Describir_Tablas.exec_()

    def Ver_Tablas_DisponiblesFirebird(self):
        Ver_Tablas = Ventana_Ayuda()
        Ver_Tablas.Ver_Tablas_ExistentesFBD()
        Ver_Tablas.exec_()

    def Crear_TablaNoEngine(self):
        Nueva_Tabla = Ventana_Ayuda()
        Nueva_Tabla.Crear_Nueva_TablaNoEngine()
        Nueva_Tabla.exec_()

    def Estructura_TablaFirebird(self):
        Describir_Tablas = Ventana_Ayuda()
        Describir_Tablas.Describir_TablasFirebird()
        Describir_Tablas.exec_()

    def Ver_Tablas_DisponiblesServer(self):
        Ver_Tablas = Ventana_Ayuda()
        Ver_Tablas.Ver_Tablas_ExistentesSERVER()
        Ver_Tablas.exec_()

    def Estructura_TablaServer(self):
        Describir_Tablas = Ventana_Ayuda()
        Describir_Tablas.Describir_TablasServer()
        Describir_Tablas.exec_()

    def Ver_Tablas_DisponiblesPostgre(self):
        Ver_Tablas = Ventana_Ayuda()
        Ver_Tablas.Ver_Tablas_ExistentesPostgre()
        Ver_Tablas.exec_()

    def Estructura_TablaPostgre(self):
        Describir_Tablas = Ventana_Ayuda()
        Describir_Tablas.Describir_TablasPostgre()
        Describir_Tablas.exec_()

    def Consultar_VistasSQLITE(self):
        Visualizar_Vistas = Ventana_Ayuda()
        Visualizar_Vistas.Vistas_ExistentesSQLITE()
        Visualizar_Vistas.exec_()

    def Consultar_VistasFirebird(self):
        Visualizar_Vistas = Ventana_Ayuda()
        Visualizar_Vistas.Vistas_ExistentesFirebird()
        Visualizar_Vistas.exec_()

    def Consultar_VistasSERVER(self):
        Visualizar_Vistas = Ventana_Ayuda()
        Visualizar_Vistas.Vistas_ExistentesSERVER()
        Visualizar_Vistas.exec_()

    def Consultar_VistasPostgre(self):
        Visualizar_Vistas = Ventana_Ayuda()
        Visualizar_Vistas.Vistas_ExistentesPostgre()
        Visualizar_Vistas.exec_()

    def Crear_ProcedimientoFDB(self):
        Nuevo_Procedimiento = Ventana_Ayuda()
        Nuevo_Procedimiento.Crear_ProcedimientoFirebird()
        Nuevo_Procedimiento.exec_()

    def Llamar_ProcedimientoFDB(self):
        Activar_Procedimiento = Ventana_Ayuda()
        Activar_Procedimiento.Llamar_ProcedimientoFirebird()
        Activar_Procedimiento.exec_()

    def Ver_ProcedimientosFDB(self):
        Consultar_Procedimientos = Ventana_Ayuda()
        Consultar_Procedimientos.Ver_Procedimientos_ExistentesFirebird()
        Consultar_Procedimientos.exec_()

    def Crear_ProcedimientoServer(self):
        Nuevo_Procedimiento = Ventana_Ayuda()
        Nuevo_Procedimiento.Crear_ProcedimientoServer()
        Nuevo_Procedimiento.exec_()

    def Llamar_ProcedimientoServer(self):
        Activar_Procedimiento = Ventana_Ayuda()
        Activar_Procedimiento.Llamar_ProcedimientoServer()
        Activar_Procedimiento.exec_()

    def Ver_ProcedimientosServer(self):
        Consultar_Procedimientos = Ventana_Ayuda()
        Consultar_Procedimientos.Ver_Procedimientos_ExistentesServer()
        Consultar_Procedimientos.exec_()


if __name__ == '__main__':
    programa = QApplication(sys.argv)
    validar = Ventana_Principal()
    validar.show()
    programa.exec_()

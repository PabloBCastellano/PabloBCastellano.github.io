import urllib.request
import urllib.parse
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QMainWindow, QMessageBox, QDialog, QPushButton, QListWidgetItem, QTableWidget, QTableWidgetItem, QMenu, QSystemTrayIcon, QTreeWidgetItem
from PyQt5 import uic
from PyQt5 import QtCore


class Usuario_Detalle(QDialog, QPushButton):
    def __init__(self):
        QDialog.__init__(self)
        QLabel.__init__(self)

        uic.loadUi("Detalles_Usuario.ui", self)
        self.setWindowFlag(QtCore.Qt.WindowCloseButtonHint,True)
        self.setWindowTitle("Detalles del Usuario")

    def EndPointVerUsuario_WebServiceRest(self):
        self.Dni = self.Dni_Entrada.text()
        url = 'http://localhost:9090/segundoproyecto/api/detalleUsuario/'+self.Dni
        f = urllib.request.urlopen(url)
        Datos=f.read().decode('utf-8')
        if(Datos==""):
            Datos="Usuario con dni solicitado no encontrado en base de datos"
            
        self.Mostrar_Datos.setText(Datos)
if __name__ == '__main__':
    programa = QApplication(sys.argv)
    validar = APIWEB()
    validar.show()
    programa.exec_()